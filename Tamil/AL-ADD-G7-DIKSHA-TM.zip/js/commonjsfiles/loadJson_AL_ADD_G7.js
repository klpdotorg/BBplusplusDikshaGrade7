var AL_ADD_G7_JSON = {
	orangefishanim:{"frames": [

		{
			"filename": "Symbol 21 copy instance 10000",
			"frame": {"x":0,"y":0,"w":59,"h":32},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":32},
			"sourceSize": {"w":59,"h":32}
		}
		,{ 
			"filename": "Symbol 21 copy instance 10001",
			"frame": {"x":59,"y":0,"w":59,"h":32},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":32},
			"sourceSize": {"w":59,"h":32}
		}
		,{
			"filename": "Symbol 21 copy instance 10002",
			"frame": {"x":118,"y":0,"w":59,"h":32},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":32},
			"sourceSize": {"w":59,"h":32}
		}
		,{
			"filename": "Symbol 21 copy instance 10003",
			"frame": {"x":177,"y":0,"w":59,"h":32},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":32},
			"sourceSize": {"w":59,"h":32}
		}
		,{
			"filename": "Symbol 21 copy instance 10004",
			"frame": {"x":236,"y":0,"w":59,"h":32},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":32},
			"sourceSize": {"w":59,"h":32}
		}
		,{
			"filename": "Symbol 21 copy instance 10005",
			"frame": {"x":295,"y":0,"w":59,"h":32},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":32},
			"sourceSize": {"w":59,"h":32}
		}
		,{
			"filename": "Symbol 21 copy instance 10006",
			"frame": {"x":354,"y":0,"w":59,"h":32},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":32},
			"sourceSize": {"w":59,"h":32}
		}
		,{
			"filename": "Symbol 21 copy instance 10007",
			"frame": {"x":413,"y":0,"w":59,"h":32},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":32},
			"sourceSize": {"w":59,"h":32}
		}
		,{
			"filename": "Symbol 21 copy instance 10008",
			"frame": {"x":472,"y":0,"w":59,"h":32},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":32},
			"sourceSize": {"w":59,"h":32}
		}
		,{
			"filename": "Symbol 21 copy instance 10009",
			"frame": {"x":531,"y":0,"w":59,"h":32},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":32},
			"sourceSize": {"w":59,"h":32}
		}
		,{
			"filename": "Symbol 21 copy instance 10010",
			"frame": {"x":590,"y":0,"w":59,"h":32},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":32},
			"sourceSize": {"w":59,"h":32}
		}
		,{
			"filename": "Symbol 21 copy instance 10011",
			"frame": {"x":649,"y":0,"w":59,"h":32},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":32},
			"sourceSize": {"w":59,"h":32}
		}
		,{
			"filename": "Symbol 21 copy instance 10012",
			"frame": {"x":708,"y":0,"w":59,"h":32},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":32},
			"sourceSize": {"w":59,"h":32}
		}
		,{
			"filename": "Symbol 21 copy instance 10013",
			"frame": {"x":767,"y":0,"w":59,"h":32},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":32},
			"sourceSize": {"w":59,"h":32}
		}
		,{
			"filename": "Symbol 21 copy instance 10014",
			"frame": {"x":826,"y":0,"w":59,"h":32},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":32},
			"sourceSize": {"w":59,"h":32}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.4.185",
			"image": "Orenge  fish anim.png",
			"format": "RGBA8888",
			"size": {"w":888,"h":32},
			"scale": "1"
		}
		},
		answerBoxJson: {"frames": [

			{
				"filename": "Symbol 14 instance 10000",
				"frame": {"x":0,"y":0,"w":63,"h":47},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":63,"h":47},
				"sourceSize": {"w":63,"h":47}
			}
			,{
				"filename": "Symbol 14 instance 10001",
				"frame": {"x":63,"y":0,"w":63,"h":47},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":63,"h":47},
				"sourceSize": {"w":63,"h":47}
			}],
			"meta": {
				"app": "Adobe Animate",
				"version": "22.0.0.93",
				"image": "text box_5.png",
				"format": "RGBA8888",
				"size": {"w":127,"h":47},
				"scale": "1"
			}
		},
		bluefishanim: {"frames": [
	
			{
				"filename": "Symbol 21 instance 10000",
				"frame": {"x":0,"y":0,"w":58,"h":32},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":58,"h":32},
				"sourceSize": {"w":58,"h":32}
			}
			,{
				"filename": "Symbol 21 instance 10001",
				"frame": {"x":58,"y":0,"w":58,"h":32},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":58,"h":32},
				"sourceSize": {"w":58,"h":32}
			}
			,{
				"filename": "Symbol 21 instance 10002",
				"frame": {"x":116,"y":0,"w":58,"h":32},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":58,"h":32},
				"sourceSize": {"w":58,"h":32}
			}
			,{
				"filename": "Symbol 21 instance 10003",
				"frame": {"x":174,"y":0,"w":58,"h":32},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":58,"h":32},
				"sourceSize": {"w":58,"h":32}
			}
			,{
				"filename": "Symbol 21 instance 10004",
				"frame": {"x":232,"y":0,"w":58,"h":32},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":58,"h":32},
				"sourceSize": {"w":58,"h":32}
			}
			,{
				"filename": "Symbol 21 instance 10005",
				"frame": {"x":290,"y":0,"w":58,"h":32},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":58,"h":32},
				"sourceSize": {"w":58,"h":32}
			}
			,{
				"filename": "Symbol 21 instance 10006",
				"frame": {"x":348,"y":0,"w":58,"h":32},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":58,"h":32},
				"sourceSize": {"w":58,"h":32}
			}
			,{
				"filename": "Symbol 21 instance 10007",
				"frame": {"x":406,"y":0,"w":58,"h":32},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":58,"h":32},
				"sourceSize": {"w":58,"h":32}
			}
			,{
				"filename": "Symbol 21 instance 10008",
				"frame": {"x":464,"y":0,"w":58,"h":32},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":58,"h":32},
				"sourceSize": {"w":58,"h":32}
			}
			,{
				"filename": "Symbol 21 instance 10009",
				"frame": {"x":522,"y":0,"w":58,"h":32},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":58,"h":32},
				"sourceSize": {"w":58,"h":32}
			}
			,{
				"filename": "Symbol 21 instance 10010",
				"frame": {"x":580,"y":0,"w":58,"h":32},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":58,"h":32},
				"sourceSize": {"w":58,"h":32}
			}
			,{
				"filename": "Symbol 21 instance 10011",
				"frame": {"x":638,"y":0,"w":58,"h":32},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":58,"h":32},
				"sourceSize": {"w":58,"h":32}
			}
			,{
				"filename": "Symbol 21 instance 10012",
				"frame": {"x":696,"y":0,"w":58,"h":32},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":58,"h":32},
				"sourceSize": {"w":58,"h":32}
			}
			,{
				"filename": "Symbol 21 instance 10013",
				"frame": {"x":754,"y":0,"w":58,"h":32},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":58,"h":32},
				"sourceSize": {"w":58,"h":32}
			}
			,{
				"filename": "Symbol 21 instance 10014",
				"frame": {"x":812,"y":0,"w":58,"h":32},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":58,"h":32},
				"sourceSize": {"w":58,"h":32}
			}],
			"meta": {
				"app": "Adobe Animate",
				"version": "22.0.4.185",
				"image": "Blue fish anim.png",
				"format": "RGBA8888",
				"size": {"w":874,"h":32},
				"scale": "1"
			}
			},
	starAnimJson : {"frames": [

		{
			"filename": "Symbol 10 copy instance 10000",
			"frame": {"x":0,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10001",
			"frame": {"x":0,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10002",
			"frame": {"x":0,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10003",
			"frame": {"x":0,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10004",
			"frame": {"x":33,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10005",
			"frame": {"x":33,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10006",
			"frame": {"x":33,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10007",
			"frame": {"x":33,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10008",
			"frame": {"x":66,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10009",
			"frame": {"x":66,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10010",
			"frame": {"x":66,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10011",
			"frame": {"x":66,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10012",
			"frame": {"x":99,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10013",
			"frame": {"x":99,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10014",
			"frame": {"x":99,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10015",
			"frame": {"x":99,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10016",
			"frame": {"x":132,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10017",
			"frame": {"x":132,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10018",
			"frame": {"x":132,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10019",
			"frame": {"x":132,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10020",
			"frame": {"x":165,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10021",
			"frame": {"x":165,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10022",
			"frame": {"x":165,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10023",
			"frame": {"x":165,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10024",
			"frame": {"x":198,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10025",
			"frame": {"x":198,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10026",
			"frame": {"x":198,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10027",
			"frame": {"x":198,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10028",
			"frame": {"x":231,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10029",
			"frame": {"x":231,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10030",
			"frame": {"x":231,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10031",
			"frame": {"x":231,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10032",
			"frame": {"x":264,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10033",
			"frame": {"x":264,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10034",
			"frame": {"x":264,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10035",
			"frame": {"x":264,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "st.png",
			"format": "RGB8",
			"size": {"w":334,"h":479},
			"scale": "1"
		}
		},

		speakerJson : {"frames": [

			{
				"filename": "Symbol 5 instance 10000",
				"frame": {"x":0,"y":0,"w":41,"h":30},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":41,"h":30},
				"sourceSize": {"w":41,"h":30}
			},
			{
				"filename": "Symbol 5 instance 10001",
				"frame": {"x":0,"y":30,"w":41,"h":30},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":41,"h":30},
				"sourceSize": {"w":41,"h":30}
			}],
			"meta": {
				"app": "Adobe Animate",
				"version": "15.1.0.210",
				"image": "s.png",
				"format": "RGB8",
				"size": {"w":44,"h":64},
				"scale": "1"
			}
		},

		btnJson : {"frames": [

		{
			"filename": "Symbol 1 instance 10000",
			"frame": {"x":0,"y":0,"w":212,"h":71},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":212,"h":71},
			"sourceSize": {"w":212,"h":71}
		}
		,{
			"filename": "Symbol 1 instance 10001",
			"frame": {"x":0,"y":71,"w":212,"h":71},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":212,"h":71},
			"sourceSize": {"w":212,"h":71}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "16.5.1.104",
			"image": "b1.png",
			"format": "RGB8",
			"size": {"w":213,"h":144},
			"scale": "1"
		}
		},

		replyJson : {"frames": [

		{
			"filename": "Symbol 8 instance 10000",
			"frame": {"x":0,"y":0,"w":47,"h":47},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
			"sourceSize": {"w":47,"h":47}
		}
		,{
			"filename": "Symbol 8 instance 10001",
			"frame": {"x":47,"y":0,"w":47,"h":47},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
			"sourceSize": {"w":47,"h":47}
		}
		,{
			"filename": "Symbol 8 instance 10002",
			"frame": {"x":0,"y":0,"w":47,"h":47},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
			"sourceSize": {"w":47,"h":47}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "Back btn.png",
			"format": "RGBA8888",
			"size": {"w":98,"h":48},
			"scale": "1"
		}
		},

 		backbtnJson : {"frames": [

		{
			"filename": "Symbol 9 instance 10000",
			"frame": {"x":0,"y":0,"w":41,"h":29},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":29},
			"sourceSize": {"w":41,"h":29}
		}
		,{
			"filename": "Symbol 9 instance 10001",
			"frame": {"x":0,"y":29,"w":41,"h":29},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":29},
			"sourceSize": {"w":41,"h":29}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "back.png",
			"format": "RGB8",
			"size": {"w":44,"h":64},
			"scale": "1"
		}
		},

		tickJson: {
			"frames": [
	
				{
					"filename": "Symbol 10 copy instance 10000",
					"frame": { "x": 0, "y": 0, "w": 68, "h": 66 },
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 66 },
					"sourceSize": { "w": 68, "h": 66 }
				}
				, {
					"filename": "Symbol 10 copy instance 10001",
					"frame": { "x": 68, "y": 0, "w": 68, "h": 66 },
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 66 },
					"sourceSize": { "w": 68, "h": 66 }
				}],
			"meta": {
				"app": "Adobe Animate",
				"version": "20.0.1.19255",
				"image": "Right btn0002.png",
				"format": "RGBA8888",
				"size": { "w": 138, "h": 66 },
				"scale": "1"
			}
		},
	
			
		nextbtnJson: {"frames": [

		{
			"filename": "Symbol 6 instance 10000",
			"frame": {"x":0,"y":0,"w":59,"h":60},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":60},
			"sourceSize": {"w":59,"h":60}
		}
		,{
			"filename": "Symbol 6 instance 10001",
			"frame": {"x":0,"y":60,"w":59,"h":60},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":59,"h":60},
			"sourceSize": {"w":59,"h":60}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.1.115",
			"image": "N.png",
			"format": "RGB8",
			"size": {"w":64,"h":128},
			"scale": "1"
		}
		},
		homebtnJson:{"frames": [

			{
				"filename": "Symbol 4 instance 10000",
				"frame": {"x":0,"y":0,"w":60,"h":60},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
				"sourceSize": {"w":60,"h":60}
			}
			,{
				"filename": "Symbol 4 instance 10001",
				"frame": {"x":0,"y":60,"w":60,"h":60},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
				"sourceSize": {"w":60,"h":60}
			}],
			"meta": {
				"app": "Adobe Animate",
				"version": "18.0.1.115",
				"image": "H.png",
				"format": "RGB8",
				"size": {"w":64,"h":128},
				"scale": "1"
			}

		},

		numberpadJson: {"frames": [

			{
				"filename": "Symbol 3 instance 10000",
				"frame": {"x":0,"y":0,"w":68,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
				"sourceSize": {"w":68,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10001",
				"frame": {"x":68,"y":0,"w":68,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
				"sourceSize": {"w":68,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10002",
				"frame": {"x":136,"y":0,"w":68,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
				"sourceSize": {"w":68,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10003",
				"frame": {"x":204,"y":0,"w":68,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
				"sourceSize": {"w":68,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10004",
				"frame": {"x":272,"y":0,"w":68,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
				"sourceSize": {"w":68,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10005",
				"frame": {"x":340,"y":0,"w":68,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
				"sourceSize": {"w":68,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10006",
				"frame": {"x":408,"y":0,"w":68,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
				"sourceSize": {"w":68,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10007",
				"frame": {"x":476,"y":0,"w":68,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
				"sourceSize": {"w":68,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10008",
				"frame": {"x":544,"y":0,"w":68,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
				"sourceSize": {"w":68,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10009",
				"frame": {"x":612,"y":0,"w":68,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
				"sourceSize": {"w":68,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10010",
				"frame": {"x":680,"y":0,"w":68,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
				"sourceSize": {"w":68,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10011",
				"frame": {"x":748,"y":0,"w":68,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
				"sourceSize": {"w":68,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10012",
				"frame": {"x":816,"y":0,"w":68,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
				"sourceSize": {"w":68,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10013",
				"frame": {"x":884,"y":0,"w":68,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
				"sourceSize": {"w":68,"h":68}
			}],
			"meta": {
				"app": "Adobe Animate",
				"version": "20.0.1.19255",
				"image": "number 0 to 9.png",
				"format": "RGBA8888",
				"size": {"w":953,"h":68},
				"scale": "1"
			}
			},
	

		BlueFishJson:{"frames": [

			{
				"filename": "Symbol 11 instance 10000",
				"frame": {"x":0,"y":0,"w":59,"h":50},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":59,"h":50},
				"sourceSize": {"w":59,"h":50}
			}
			,{
				"filename": "Symbol 11 instance 10001",
				"frame": {"x":59,"y":0,"w":59,"h":50},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":59,"h":50},
				"sourceSize": {"w":59,"h":50}
			}
			,{
				"filename": "Symbol 11 instance 10002",
				"frame": {"x":118,"y":0,"w":59,"h":50},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":59,"h":50},
				"sourceSize": {"w":59,"h":50}
			}],
			"meta": {
				"app": "Adobe Animate",
				"version": "20.0.1.19255",
				"image": "Blue fish.png",
				"format": "RGBA8888",
				"size": {"w":177,"h":50},
				"scale": "1"
			}
		}
			,
		RedFishJson:{"frames": [

			{
				"filename": "Symbol 12 instance 10000",
				"frame": {"x":0,"y":0,"w":61,"h":50},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":61,"h":50},
				"sourceSize": {"w":61,"h":50}
			}
			,{
				"filename": "Symbol 12 instance 10001",
				"frame": {"x":61,"y":0,"w":61,"h":50},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":61,"h":50},
				"sourceSize": {"w":61,"h":50}
			}
			,{
				"filename": "Symbol 12 instance 10002",
				"frame": {"x":122,"y":0,"w":61,"h":50},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":61,"h":50},
				"sourceSize": {"w":61,"h":50}
			}],
			"meta": {
				"app": "Adobe Animate",
				"version": "20.0.1.19255",
				"image": "ALS-02-G6.png",
				"format": "RGBA8888",
				"size": {"w":184,"h":50},
				"scale": "1"
			}
			}
			,
		GrassOneJson:{"frames": [

			{
				"filename": "Symbol 4 instance 10000",
				"frame": {"x":0,"y":0,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10001",
				"frame": {"x":82,"y":0,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10002",
				"frame": {"x":164,"y":0,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10003",
				"frame": {"x":246,"y":0,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10004",
				"frame": {"x":328,"y":0,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10005",
				"frame": {"x":410,"y":0,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10006",
				"frame": {"x":492,"y":0,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10007",
				"frame": {"x":574,"y":0,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10008",
				"frame": {"x":656,"y":0,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10009",
				"frame": {"x":738,"y":0,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10010",
				"frame": {"x":820,"y":0,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10011",
				"frame": {"x":0,"y":131,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10012",
				"frame": {"x":82,"y":131,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10013",
				"frame": {"x":164,"y":131,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10014",
				"frame": {"x":246,"y":131,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10015",
				"frame": {"x":328,"y":131,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10016",
				"frame": {"x":410,"y":131,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10017",
				"frame": {"x":492,"y":131,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10018",
				"frame": {"x":574,"y":131,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10019",
				"frame": {"x":656,"y":131,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10020",
				"frame": {"x":738,"y":131,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10021",
				"frame": {"x":820,"y":131,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10022",
				"frame": {"x":0,"y":262,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10023",
				"frame": {"x":82,"y":262,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10024",
				"frame": {"x":164,"y":262,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10025",
				"frame": {"x":246,"y":262,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10026",
				"frame": {"x":328,"y":262,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10027",
				"frame": {"x":410,"y":262,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10028",
				"frame": {"x":492,"y":262,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10029",
				"frame": {"x":574,"y":262,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}
			,{
				"filename": "Symbol 4 instance 10030",
				"frame": {"x":656,"y":262,"w":82,"h":131},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":82,"h":131},
				"sourceSize": {"w":82,"h":131}
			}],
			"meta": {
				"app": "Adobe Animate",
				"version": "20.0.1.19255",
				"image": "grass_1.png",
				"format": "RGBA8888",
				"size": {"w":906,"h":401},
				"scale": "1"
			}
			},
		GrassTwoJson:{"frames": [

			{
				"filename": "Symbol 7 instance 10000",
				"frame": {"x":0,"y":0,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10001",
				"frame": {"x":53,"y":0,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10002",
				"frame": {"x":106,"y":0,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10003",
				"frame": {"x":159,"y":0,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10004",
				"frame": {"x":212,"y":0,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10005",
				"frame": {"x":265,"y":0,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10006",
				"frame": {"x":318,"y":0,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10007",
				"frame": {"x":371,"y":0,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10008",
				"frame": {"x":424,"y":0,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10009",
				"frame": {"x":477,"y":0,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10010",
				"frame": {"x":530,"y":0,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10011",
				"frame": {"x":583,"y":0,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10012",
				"frame": {"x":636,"y":0,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10013",
				"frame": {"x":0,"y":97,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10014",
				"frame": {"x":53,"y":97,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10015",
				"frame": {"x":106,"y":97,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10016",
				"frame": {"x":159,"y":97,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10017",
				"frame": {"x":212,"y":97,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10018",
				"frame": {"x":265,"y":97,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10019",
				"frame": {"x":318,"y":97,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10020",
				"frame": {"x":371,"y":97,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10021",
				"frame": {"x":424,"y":97,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10022",
				"frame": {"x":477,"y":97,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10023",
				"frame": {"x":530,"y":97,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}
			,{
				"filename": "Symbol 7 instance 10024",
				"frame": {"x":583,"y":97,"w":53,"h":97},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":53,"h":97},
				"sourceSize": {"w":53,"h":97}
			}],
			"meta": {
				"app": "Adobe Animate",
				"version": "20.0.1.19255",
				"image": "grass_2.png",
				"format": "RGBA8888",
				"size": {"w":716,"h":194},
				"scale": "1"
			}
			},
		TickbtnJson:{"frames": [

			{
				"filename": "Symbol 10 instance 10000",
				"frame": {"x":0,"y":0,"w":67,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":67,"h":68},
				"sourceSize": {"w":67,"h":68}
			}
			,{
				"filename": "Symbol 10 instance 10001",
				"frame": {"x":67,"y":0,"w":67,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":67,"h":68},
				"sourceSize": {"w":67,"h":68}
			}],
			"meta": {
				"app": "Adobe Animate",
				"version": "20.0.1.19255",
				"image": "ALP-01-G6.png",
				"format": "RGBA8888",
				"size": {"w":134,"h":68},
				"scale": "1"
			}
			},

			TextBox:{"frames": [

				{
					"filename": "Symbol 18 instance 10000",
					"frame": {"x":0,"y":0,"w":226,"h":77},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":226,"h":77},
					"sourceSize": {"w":226,"h":77}
				}
				,{
					"filename": "Symbol 18 instance 10001",
					"frame": {"x":226,"y":0,"w":226,"h":77},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":226,"h":77},
					"sourceSize": {"w":226,"h":77}
				}],
				"meta": {
					"app": "Adobe Animate",
					"version": "20.0.1.19255",
					"image": "Text box_4.png",
					"format": "RGBA8888",
					"size": {"w":452,"h":77},
					"scale": "1"
				}
				},
				SquareBoxJson:{"frames": [

					{
						"filename": "Symbol 5 instance 10000",
						"frame": {"x":0,"y":0,"w":55,"h":54},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":55,"h":54},
						"sourceSize": {"w":55,"h":54}
					}
					,{
						"filename": "Symbol 5 instance 10001",
						"frame": {"x":55,"y":0,"w":55,"h":54},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":55,"h":54},
						"sourceSize": {"w":55,"h":54}
					}],
					"meta": {
						"app": "Adobe Animate",
						"version": "20.0.1.19255",
						"image": "NSF-2B-G6 new box.png",
						"format": "RGBA8888",
						"size": {"w":110,"h":54},
						"scale": "1"
					}
					},
				bubbles:{"frames": [

					{
						"filename": "Symbol 3 instance 10000",
						"frame": {"x":0,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10001",
						"frame": {"x":26,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10002",
						"frame": {"x":52,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10003",
						"frame": {"x":78,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10004",
						"frame": {"x":104,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10005",
						"frame": {"x":130,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10006",
						"frame": {"x":156,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10007",
						"frame": {"x":182,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10008",
						"frame": {"x":208,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10009",
						"frame": {"x":234,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10010",
						"frame": {"x":260,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10011",
						"frame": {"x":286,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10012",
						"frame": {"x":312,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10013",
						"frame": {"x":338,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10014",
						"frame": {"x":364,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10015",
						"frame": {"x":390,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10016",
						"frame": {"x":416,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10017",
						"frame": {"x":442,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10018",
						"frame": {"x":468,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10019",
						"frame": {"x":494,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10020",
						"frame": {"x":520,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10021",
						"frame": {"x":546,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10022",
						"frame": {"x":572,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10023",
						"frame": {"x":598,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10024",
						"frame": {"x":624,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10025",
						"frame": {"x":650,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10026",
						"frame": {"x":676,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10027",
						"frame": {"x":702,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10028",
						"frame": {"x":728,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10029",
						"frame": {"x":754,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10030",
						"frame": {"x":780,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10031",
						"frame": {"x":806,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10032",
						"frame": {"x":832,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10033",
						"frame": {"x":858,"y":0,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10034",
						"frame": {"x":0,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10035",
						"frame": {"x":26,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10036",
						"frame": {"x":52,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10037",
						"frame": {"x":78,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10038",
						"frame": {"x":104,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10039",
						"frame": {"x":130,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10040",
						"frame": {"x":156,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10041",
						"frame": {"x":182,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10042",
						"frame": {"x":208,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10043",
						"frame": {"x":234,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10044",
						"frame": {"x":260,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10045",
						"frame": {"x":286,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10046",
						"frame": {"x":312,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10047",
						"frame": {"x":338,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10048",
						"frame": {"x":364,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10049",
						"frame": {"x":390,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10050",
						"frame": {"x":416,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10051",
						"frame": {"x":442,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10052",
						"frame": {"x":468,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10053",
						"frame": {"x":494,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}
					,{
						"filename": "Symbol 3 instance 10054",
						"frame": {"x":520,"y":211,"w":26,"h":211},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":26,"h":211},
						"sourceSize": {"w":26,"h":211}
					}],
					"meta": {
						"app": "Adobe Animate",
						"version": "20.0.1.19255",
						"image": "bubbels.png",
						"format": "RGBA8888",
						"size": {"w":900,"h":488},
						"scale": "1"
					}
					},
					
				
					matchJson:{"frames": [

						{
							"filename": "Symbol 3 instance 10000",
							"frame": {"x":0,"y":0,"w":57,"h":57},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":57,"h":57},
							"sourceSize": {"w":57,"h":57}
						}
						,{
							"filename": "Symbol 3 instance 10001",
							"frame": {"x":57,"y":0,"w":57,"h":57},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":57,"h":57},
							"sourceSize": {"w":57,"h":57}
						}],
						"meta": {
							"app": "Adobe Animate",
							"version": "22.0.4.185",
							"image": "Maches_1.png",
							"format": "RGBA8888",
							"size": {"w":115,"h":59},
							"scale": "1"
						}
						},
						LineJson: {"frames": [

							{
								"filename": "Symbol 8 instance 10000",
								"frame": {"x":0,"y":0,"w":22,"h":248},
								"rotated": false,
								"trimmed": false,
								"spriteSourceSize": {"x":0,"y":0,"w":22,"h":248},
								"sourceSize": {"w":22,"h":248}
							}
							,{
								"filename": "Symbol 8 instance 10001",
								"frame": {"x":22,"y":0,"w":22,"h":248},
								"rotated": false,
								"trimmed": false,
								"spriteSourceSize": {"x":0,"y":0,"w":22,"h":248},
								"sourceSize": {"w":22,"h":248}
							}],
							"meta": {
								"app": "Adobe Animate",
								"version": "22.0.4.185",
								"image": "Line & Maches.png",
								"format": "RGBA8888",
								"size": {"w":50,"h":250},
								"scale": "1"
							}
							},

						BoxJson:{"frames": [

								{
									"filename": "Symbol 1 instance 10000",
									"frame": {"x":0,"y":0,"w":164,"h":77},
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": {"x":0,"y":0,"w":164,"h":77},
									"sourceSize": {"w":164,"h":77}
								}
								,{
									"filename": "Symbol 1 instance 10001",
									"frame": {"x":164,"y":0,"w":164,"h":77},
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": {"x":0,"y":0,"w":164,"h":77},
									"sourceSize": {"w":164,"h":77}
								}],
								"meta": {
									"app": "Adobe Animate",
									"version": "22.0.4.185",
									"image": "Text box_1.png",
									"format": "RGBA8888",
									"size": {"w":328,"h":77},
									"scale": "1"
								}
								},

						Chesscoin1Json :{"frames": [

							{
								"filename": "Symbol 2 instance 10000",
								"frame": {"x":0,"y":0,"w":35,"h":62},
								"rotated": false,
								"trimmed": false,
								"spriteSourceSize": {"x":0,"y":0,"w":35,"h":62},
								"sourceSize": {"w":35,"h":62}
							}
							,{
								"filename": "Symbol 2 instance 10001",
								"frame": {"x":35,"y":0,"w":35,"h":62},
								"rotated": false,
								"trimmed": false,
								"spriteSourceSize": {"x":0,"y":0,"w":35,"h":62},
								"sourceSize": {"w":35,"h":62}
							}],
							"meta": {
								"app": "Adobe Animate",
								"version": "22.0.4.185",
								"image": "Chess Coins_1.png",
								"format": "RGBA8888",
								"size": {"w":72,"h":62},
								"scale": "1"
							}
							},

						Chesscoin2Json: {"frames": [

							{
								"filename": "Symbol 1 instance 10000",
								"frame": {"x":0,"y":0,"w":57,"h":81},
								"rotated": false,
								"trimmed": false,
								"spriteSourceSize": {"x":0,"y":0,"w":57,"h":81},
								"sourceSize": {"w":57,"h":81}
							}
							,{
								"filename": "Symbol 1 instance 10001",
								"frame": {"x":57,"y":0,"w":57,"h":81},
								"rotated": false,
								"trimmed": false,
								"spriteSourceSize": {"x":0,"y":0,"w":57,"h":81},
								"sourceSize": {"w":57,"h":81}
							}],
							"meta": {
								"app": "Adobe Animate",
								"version": "22.0.4.185",
								"image": "Chess Coins_2.png",
								"format": "RGBA8888",
								"size": {"w":114,"h":81},
								"scale": "1"
							}
							},

						Trophy1Json :{"frames": [

							{
								"filename": "Symbol 7 copy instance 10000",
								"frame": {"x":0,"y":0,"w":42,"h":61},
								"rotated": false,
								"trimmed": false,
								"spriteSourceSize": {"x":0,"y":0,"w":42,"h":61},
								"sourceSize": {"w":42,"h":61}
							}
							,{
								"filename": "Symbol 7 copy instance 10001",
								"frame": {"x":42,"y":0,"w":42,"h":61},
								"rotated": false,
								"trimmed": false,
								"spriteSourceSize": {"x":0,"y":0,"w":42,"h":61},
								"sourceSize": {"w":42,"h":61}
							}],
							"meta": {
								"app": "Adobe Animate",
								"version": "22.0.4.185",
								"image": "Trophy_1.png",
								"format": "RGBA8888",
								"size": {"w":85,"h":61},
								"scale": "1"
							}
							},

						Trophy2Json : {"frames": [

							{
								"filename": "Symbol 7 instance 10000",
								"frame": {"x":0,"y":0,"w":58,"h":81},
								"rotated": false,
								"trimmed": false,
								"spriteSourceSize": {"x":0,"y":0,"w":58,"h":81},
								"sourceSize": {"w":58,"h":81}
							}
							,{
								"filename": "Symbol 7 instance 10001",
								"frame": {"x":58,"y":0,"w":58,"h":81},
								"rotated": false,
								"trimmed": false,
								"spriteSourceSize": {"x":0,"y":0,"w":58,"h":81},
								"sourceSize": {"w":58,"h":81}
							}],
							"meta": {
								"app": "Adobe Animate",
								"version": "22.0.4.185",
								"image": "Trophy_2.png",
								"format": "RGBA8888",
								"size": {"w":116,"h":81},
								"scale": "1"
							}
							},
							SquareBoxJson:{"frames": [

								{
									"filename": "Symbol 5 instance 10000",
									"frame": {"x":0,"y":0,"w":55,"h":54},
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": {"x":0,"y":0,"w":55,"h":54},
									"sourceSize": {"w":55,"h":54}
								}
								,{
									"filename": "Symbol 5 instance 10001",
									"frame": {"x":55,"y":0,"w":55,"h":54},
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": {"x":0,"y":0,"w":55,"h":54},
									"sourceSize": {"w":55,"h":54}
								}],
								"meta": {
									"app": "Adobe Animate",
									"version": "20.0.1.19255",
									"image": "NSF-2B-G6 new box.png",
									"format": "RGBA8888",
									"size": {"w":110,"h":54},
									"scale": "1"
								}
								},
								
								bulbBtnJson	: {"frames": [

									{
										"filename": "Symbol 1 instance 10000",
										"frame": {"x":0,"y":0,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10001",
										"frame": {"x":66,"y":0,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10002",
										"frame": {"x":132,"y":0,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10003",
										"frame": {"x":0,"y":49,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10004",
										"frame": {"x":66,"y":49,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10005",
										"frame": {"x":132,"y":49,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10006",
										"frame": {"x":0,"y":98,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10007",
										"frame": {"x":66,"y":98,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10008",
										"frame": {"x":132,"y":98,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10009",
										"frame": {"x":0,"y":147,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10010",
										"frame": {"x":66,"y":147,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10011",
										"frame": {"x":132,"y":147,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10012",
										"frame": {"x":0,"y":196,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10013",
										"frame": {"x":66,"y":196,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10014",
										"frame": {"x":132,"y":196,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10015",
										"frame": {"x":0,"y":245,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10016",
										"frame": {"x":66,"y":245,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10017",
										"frame": {"x":132,"y":245,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}
									,{
										"filename": "Symbol 1 instance 10018",
										"frame": {"x":0,"y":294,"w":66,"h":49},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
										"sourceSize": {"w":66,"h":49}
									}],
									"meta": {
										"app": "Adobe Animate",
										"version": "18.0.0.107",
										"image": "bulb anim.png",
										"format": "RGBA8888",
										"size": {"w":198,"h":347},
										"scale": "1"
									}
								},

								eraserJson : {"frames": [

									{
										"filename": "Symbol 22 instance 10000",
										"frame": {"x":0,"y":0,"w":61,"h":62},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":61,"h":62},
										"sourceSize": {"w":61,"h":62}
									}
									,{
										"filename": "Symbol 22 instance 10001",
										"frame": {"x":61,"y":0,"w":61,"h":62},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":61,"h":62},
										"sourceSize": {"w":61,"h":62}
									}],
									"meta": {
										"app": "Adobe Animate",
										"version": "22.0.0.93",
										"image": "Btn_2.png",
										"format": "RGBA8888",
										"size": {"w":126,"h":62},
										"scale": "1"
									}
								},

								symbol1Json : {"frames": [

									{
										"filename": "Symbol 13 instance 10000",
										"frame": {"x":0,"y":0,"w":91,"h":90},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":91,"h":90},
										"sourceSize": {"w":91,"h":90}
									}
									,{
										"filename": "Symbol 13 instance 10001",
										"frame": {"x":91,"y":0,"w":91,"h":90},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":91,"h":90},
										"sourceSize": {"w":91,"h":90}
									}],
									"meta": {
										"app": "Adobe Animate",
										"version": "22.0.0.93",
										"image": "symbol_1.png",
										"format": "RGBA8888",
										"size": {"w":183,"h":90},
										"scale": "1"
									}
								},

								symbol2Json : {"frames": [

									{
										"filename": "Symbol 13 copy instance 10000",
										"frame": {"x":0,"y":0,"w":91,"h":90},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":91,"h":90},
										"sourceSize": {"w":91,"h":90}
									}
									,{
										"filename": "Symbol 13 copy instance 10001",
										"frame": {"x":91,"y":0,"w":91,"h":90},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":91,"h":90},
										"sourceSize": {"w":91,"h":90}
									}],
									"meta": {
										"app": "Adobe Animate",
										"version": "22.0.0.93",
										"image": "symbol_2.png",
										"format": "RGBA8888",
										"size": {"w":183,"h":90},
										"scale": "1"
									}
								},

								symbol3Json : {"frames": [

									{
										"filename": "Symbol 13 copy 2 instance 10000",
										"frame": {"x":0,"y":0,"w":91,"h":90},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":91,"h":90},
										"sourceSize": {"w":91,"h":90}
									}
									,{
										"filename": "Symbol 13 copy 2 instance 10001",
										"frame": {"x":91,"y":0,"w":91,"h":90},
										"rotated": false,
										"trimmed": false,
										"spriteSourceSize": {"x":0,"y":0,"w":91,"h":90},
										"sourceSize": {"w":91,"h":90}
									}],
									"meta": {
										"app": "Adobe Animate",
										"version": "22.0.0.93",
										"image": "symbol_3.png",
										"format": "RGBA8888",
										"size": {"w":183,"h":90},
										"scale": "1"
									}
								},

									allColorJson : {"frames": [

										{
											"filename": "Symbol 15 instance 10000",
											"frame": {"x":0,"y":0,"w":27,"h":25},
											"rotated": false,
											"trimmed": false,
											"spriteSourceSize": {"x":0,"y":0,"w":27,"h":25},
											"sourceSize": {"w":27,"h":25}
										}
										,{
											"filename": "Symbol 15 instance 10001",
											"frame": {"x":27,"y":0,"w":27,"h":25},
											"rotated": false,
											"trimmed": false,
											"spriteSourceSize": {"x":0,"y":0,"w":27,"h":25},
											"sourceSize": {"w":27,"h":25}
										}
										,{
											"filename": "Symbol 15 instance 10002",
											"frame": {"x":54,"y":0,"w":27,"h":25},
											"rotated": false,
											"trimmed": false,
											"spriteSourceSize": {"x":0,"y":0,"w":27,"h":25},
											"sourceSize": {"w":27,"h":25}
										}
										,{
											"filename": "Symbol 15 instance 10003",
											"frame": {"x":81,"y":0,"w":27,"h":25},
											"rotated": false,
											"trimmed": false,
											"spriteSourceSize": {"x":0,"y":0,"w":27,"h":25},
											"sourceSize": {"w":27,"h":25}
										}
										,{
											"filename": "Symbol 15 instance 10004",
											"frame": {"x":108,"y":0,"w":27,"h":25},
											"rotated": false,
											"trimmed": false,
											"spriteSourceSize": {"x":0,"y":0,"w":27,"h":25},
											"sourceSize": {"w":27,"h":25}
										}
										,{
											"filename": "Symbol 15 instance 10005",
											"frame": {"x":135,"y":0,"w":27,"h":25},
											"rotated": false,
											"trimmed": false,
											"spriteSourceSize": {"x":0,"y":0,"w":27,"h":25},
											"sourceSize": {"w":27,"h":25}
										}
										,{
											"filename": "Symbol 15 instance 10006",
											"frame": {"x":162,"y":0,"w":27,"h":25},
											"rotated": false,
											"trimmed": false,
											"spriteSourceSize": {"x":0,"y":0,"w":27,"h":25},
											"sourceSize": {"w":27,"h":25}
										}
										,{
											"filename": "Symbol 15 instance 10007",
											"frame": {"x":189,"y":0,"w":27,"h":25},
											"rotated": false,
											"trimmed": false,
											"spriteSourceSize": {"x":0,"y":0,"w":27,"h":25},
											"sourceSize": {"w":27,"h":25}
										}
										,{
											"filename": "Symbol 15 instance 10008",
											"frame": {"x":216,"y":0,"w":27,"h":25},
											"rotated": false,
											"trimmed": false,
											"spriteSourceSize": {"x":0,"y":0,"w":27,"h":25},
											"sourceSize": {"w":27,"h":25}
										}
										,{
											"filename": "Symbol 15 instance 10009",
											"frame": {"x":243,"y":0,"w":27,"h":25},
											"rotated": false,
											"trimmed": false,
											"spriteSourceSize": {"x":0,"y":0,"w":27,"h":25},
											"sourceSize": {"w":27,"h":25}
										}
										,{
											"filename": "Symbol 15 instance 10010",
											"frame": {"x":270,"y":0,"w":27,"h":25},
											"rotated": false,
											"trimmed": false,
											"spriteSourceSize": {"x":0,"y":0,"w":27,"h":25},
											"sourceSize": {"w":27,"h":25}
										}],
										"meta": {
											"app": "Adobe Animate",
											"version": "22.0.0.93",
											"image": "all colour new.png",
											"format": "RGBA8888",
											"size": {"w":298,"h":25},
											"scale": "1"
										}
										},

										btn_1Json : {"frames": [

											{
												"filename": "Symbol 21 instance 10000",
												"frame": {"x":0,"y":0,"w":63,"h":62},
												"rotated": false,
												"trimmed": false,
												"spriteSourceSize": {"x":0,"y":0,"w":63,"h":62},
												"sourceSize": {"w":63,"h":62}
											}
											,{
												"filename": "Symbol 21 instance 10001",
												"frame": {"x":63,"y":0,"w":63,"h":62},
												"rotated": false,
												"trimmed": false,
												"spriteSourceSize": {"x":0,"y":0,"w":63,"h":62},
												"sourceSize": {"w":63,"h":62}
											}],
											"meta": {
												"app": "Adobe Animate",
												"version": "22.0.0.93",
												"image": "Btn_1.png",
												"format": "RGBA8888",
												"size": {"w":126,"h":62},
												"scale": "1"
											}
											}
											
										
									
										
									
							
};

