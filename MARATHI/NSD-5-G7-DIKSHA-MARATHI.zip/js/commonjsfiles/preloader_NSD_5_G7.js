Game.preloader_NSD_5_G7 = function (game) {
        this.preloadBar = null;
};

var chime, clockTick;
Game.preloader_NSD_5_G7.prototype = {
        preload: function () {

                this.load.video('NSD5G7', 'demoVideos/NSD-5-G7.mp4');  

                this.load.atlas('bulb', 'assets/commonAssets/bulb.png', null, NSD_5_G7_JSON.bulbBtnJson);
                this.load.image('skipArrow', 'assets/commonAssets/skipArrow.png');


                this.load.atlas('backbtn', 'assets/commonAssets/backbtn.png', null, NSD_5_G7_JSON.backbtnJson);
                this.load.atlas('CommonSpeakerBtn', 'assets/commonAssets/speaker.png', null, NSD_5_G7_JSON.speakerJson);
                this.load.atlas('starAnim', 'assets/commonAssets/starAnim.png', null, NSD_5_G7_JSON.starAnimJson);
               // this.load.atlas('replay', 'assets/commonAssets/reply.png', null, NSD_5_G7_JSON.replyJson);
                this.load.image('navBar', 'assets/commonAssets/navBar.png');
                this.load.image('timebg', 'assets/commonAssets/timebg.png');
                this.load.image('hand', 'assets/commonAssets/hand.png');
                //this.load.atlas('CommonHomeBtn', 'assets/commonAssets/homeBtn.png', null, NSD_5_G7_JSON.homebtnJson);
                //this.load.atlas('CommonNextBtn', 'assets/commonAssets/nextBtn.png', null, NSD_5_G7_JSON.nextbtnJson);
                this.load.image('bg', 'assets/gradeAssets/NSD-5-G7/Bg.png');


                this.load.atlas('eraser', 'assets/gradeAssets/NSD-5-G7/Btn_2.png',null,NSD_5_G7_JSON.eraser);
                this.load.atlas('reverse', 'assets/gradeAssets/NSD-5-G7/Btn_1.png', null, NSD_5_G7_JSON.reverseJson);

                this.load.image('gryBox', 'assets/gradeAssets/NSD-5-G7/gray box.png');
                this.load.image('grySmall', 'assets/gradeAssets/NSD-5-G7/gray small.png');
                this.load.image('grySmall2', 'assets/gradeAssets/NSD-5-G7/gray small2.png');
                this.load.image('blueSmall', 'assets/gradeAssets/NSD-5-G7/blue samll.png');


                this.load.image('orangeBox', 'assets/gradeAssets/NSD-5-G7/orange single.png');
                this.load.image('orangeBoxes', 'assets/gradeAssets/NSD-5-G7/orange box.png');
                this.load.image('greenBox', 'assets/gradeAssets/NSD-5-G7/green box.png');
                this.load.image('greenBoxHr', 'assets/gradeAssets/NSD-5-G7/green boxHr.png');
                this.load.image('yellowBox', 'assets/gradeAssets/NSD-5-G7/yellow box.png');
                this.load.image('yellowBox2', 'assets/gradeAssets/NSD-5-G7/yellow box_2.png');
                this.load.image('yellowTextbox', 'assets/gradeAssets/NSD-5-G7/yellow text box.png');


                this.load.image('panel_1', 'assets/gradeAssets/NSD-5-G7/panle_1.png');
                this.load.image('panel_2', 'assets/gradeAssets/NSD-5-G7/panle_2.png');
                this.load.image('panel_3', 'assets/gradeAssets/NSD-5-G7/panle_3.png');
                this.load.image('panel3', 'assets/gradeAssets/NSD-5-G7/panel3.png');

              
                this.load.image('Text box_1F', 'assets/gradeAssets/NSD-5-G7/text box.png');
                this.load.image('Text box_2', 'assets/gradeAssets/NSD-5-G7/text box_2.png');
                this.load.image('Text box_1', 'assets/gradeAssets/NSD-5-G7/text box1.png');


                // Hash yellow boxes
                this.load.image('0.1', 'assets/gradeAssets/NSD-5-G7/0.1.png');
                this.load.image('0.2', 'assets/gradeAssets/NSD-5-G7/0.2.png');
                this.load.image('0.3', 'assets/gradeAssets/NSD-5-G7/0.3.png');
                this.load.image('0.4', 'assets/gradeAssets/NSD-5-G7/0.4.png');
                this.load.image('0.5', 'assets/gradeAssets/NSD-5-G7/0.5.png');
                this.load.image('0.6', 'assets/gradeAssets/NSD-5-G7/0.6.png');
                this.load.image('0.7', 'assets/gradeAssets/NSD-5-G7/0.7.png');
                this.load.image('0.8', 'assets/gradeAssets/NSD-5-G7/0.8.png');
                this.load.image('0.15', 'assets/gradeAssets/NSD-5-G7/0.15.png');
                this.load.image('0.15R', 'assets/gradeAssets/NSD-5-G7/0.15R.png');

                this.load.image('0.25', 'assets/gradeAssets/NSD-5-G7/0.25.png');
                this.load.image('0.25R', 'assets/gradeAssets/NSD-5-G7/0.25R.png');

                this.load.image('0.35', 'assets/gradeAssets/NSD-5-G7/0.35.png');
                this.load.image('0.35R', 'assets/gradeAssets/NSD-5-G7/0.35R.png');

                this.load.image('0.75', 'assets/gradeAssets/NSD-5-G7/0.75.png');
                this.load.image('0.75R', 'assets/gradeAssets/NSD-5-G7/0.75R.png');


                this.load.image('1.25', 'assets/gradeAssets/NSD-5-G7/1.25.png');
                this.load.image('1.25R', 'assets/gradeAssets/NSD-5-G7/1.25R.png');


                this.load.atlas('TickBtn', 'assets/gradeAssets/NSD-5-G7/TickBtn.png', null, NSD_5_G7_JSON.tickJson);
                this.load.atlas('Numberpad', 'assets/gradeAssets/NSD-5-G7/number pad.png', null, NSD_5_G7_JSON.numberpadJson)
                this.load.image('numpadbg', 'assets/gradeAssets/NSD-5-G7/numbg.png');


        },

        create: function () {
                this.state.start('NSD_5_G7level1');
        },
}