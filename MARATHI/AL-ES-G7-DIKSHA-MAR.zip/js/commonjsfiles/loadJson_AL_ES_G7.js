var AL_ES_G7_JSON = { 

	starAnimJson : {"frames": [

		{
			"filename": "Symbol 10 copy instance 10000",
			"frame": {"x":0,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10001",
			"frame": {"x":0,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10002",
			"frame": {"x":0,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10003",
			"frame": {"x":0,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10004",
			"frame": {"x":33,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10005",
			"frame": {"x":33,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10006",
			"frame": {"x":33,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10007",
			"frame": {"x":33,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10008",
			"frame": {"x":66,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10009",
			"frame": {"x":66,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10010",
			"frame": {"x":66,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10011",
			"frame": {"x":66,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10012",
			"frame": {"x":99,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10013",
			"frame": {"x":99,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10014",
			"frame": {"x":99,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10015",
			"frame": {"x":99,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10016",
			"frame": {"x":132,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10017",
			"frame": {"x":132,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10018",
			"frame": {"x":132,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10019",
			"frame": {"x":132,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10020",
			"frame": {"x":165,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10021",
			"frame": {"x":165,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10022",
			"frame": {"x":165,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10023",
			"frame": {"x":165,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10024",
			"frame": {"x":198,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10025",
			"frame": {"x":198,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10026",
			"frame": {"x":198,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10027",
			"frame": {"x":198,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10028",
			"frame": {"x":231,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10029",
			"frame": {"x":231,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10030",
			"frame": {"x":231,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10031",
			"frame": {"x":231,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10032",
			"frame": {"x":264,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10033",
			"frame": {"x":264,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10034",
			"frame": {"x":264,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10035",
			"frame": {"x":264,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "st.png",
			"format": "RGB8",
			"size": {"w":334,"h":479},
			"scale": "1"
		}
		},
	speakerJson : {"frames": [

		{
			"filename": "Symbol 5 instance 10000",
			"frame": {"x":0,"y":0,"w":41,"h":30},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":30},
			"sourceSize": {"w":41,"h":30}
		},
		{
			"filename": "Symbol 5 instance 10001",
			"frame": {"x":0,"y":30,"w":41,"h":30},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":30},
			"sourceSize": {"w":41,"h":30}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "s.png",
			"format": "RGB8",
			"size": {"w":44,"h":64},
			"scale": "1"
		}
	},

	btnJson : {"frames": [

{
	"filename": "Symbol 1 instance 10000",
	"frame": {"x":0,"y":0,"w":212,"h":71},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":212,"h":71},
	"sourceSize": {"w":212,"h":71}
}
,{
	"filename": "Symbol 1 instance 10001",
	"frame": {"x":0,"y":71,"w":212,"h":71},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":212,"h":71},
	"sourceSize": {"w":212,"h":71}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "16.5.1.104",
	"image": "b1.png",
	"format": "RGB8",
	"size": {"w":213,"h":144},
	"scale": "1"
}
},

	replyJson : {"frames": [

{
	"filename": "Symbol 8 instance 10000",
	"frame": {"x":0,"y":0,"w":47,"h":47},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
	"sourceSize": {"w":47,"h":47}
}
,{
	"filename": "Symbol 8 instance 10001",
	"frame": {"x":47,"y":0,"w":47,"h":47},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
	"sourceSize": {"w":47,"h":47}
}
,{
	"filename": "Symbol 8 instance 10002",
	"frame": {"x":0,"y":0,"w":47,"h":47},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
	"sourceSize": {"w":47,"h":47}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "15.1.0.210",
	"image": "Back btn.png",
	"format": "RGBA8888",
	"size": {"w":98,"h":48},
	"scale": "1"
}
},

    backbtnJson : {"frames": [

		{
			"filename": "Symbol 9 instance 10000",
			"frame": {"x":0,"y":0,"w":41,"h":29},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":29},
			"sourceSize": {"w":41,"h":29}
		}
		,{
			"filename": "Symbol 9 instance 10001",
			"frame": {"x":0,"y":29,"w":41,"h":29},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":29},
			"sourceSize": {"w":41,"h":29}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "back.png",
			"format": "RGB8",
			"size": {"w":44,"h":64},
			"scale": "1"
		}
		},

   
    tickJson : {"frames": [

{
	"filename": "Symbol 14 copy instance 10000",
	"frame": {"x":0,"y":0,"w":58,"h":61},
	"rotated": false,
	"trimmed": true,
	"spriteSourceSize": {"x":0,"y":0,"w":64,"h":68},
	"sourceSize": {"w":64,"h":68}
}
,{
	"filename": "Symbol 14 copy instance 10001",
	"frame": {"x":58,"y":0,"w":59,"h":62},
	"rotated": false,
	"trimmed": true,
	"spriteSourceSize": {"x":5,"y":6,"w":64,"h":68},
	"sourceSize": {"w":64,"h":68}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "15.1.0.210",
	"image": "right btn.png",
	"format": "RGB8",
	"size": {"w":121,"h":62},
	"scale": "1"
}
},
        
eraserJson :{"frames": [

	{
		"filename": "Symbol 22 instance 10000",
		"frame": {"x":0,"y":0,"w":61,"h":62},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":61,"h":62},
		"sourceSize": {"w":61,"h":62}
	}
	,{
		"filename": "Symbol 22 instance 10001",
		"frame": {"x":61,"y":0,"w":61,"h":62},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":61,"h":62},
		"sourceSize": {"w":61,"h":62}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "22.0.0.93",
		"image": "Btn_2.png",
		"format": "RGBA8888",
		"size": {"w":126,"h":62},
		"scale": "1"
	}
	},

	SquareBoxJson:{"frames": [

		{
			"filename": "Symbol 5 instance 10000",
			"frame": {"x":0,"y":0,"w":55,"h":54},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":55,"h":54},
			"sourceSize": {"w":55,"h":54}
		}
		,{
			"filename": "Symbol 5 instance 10001",
			"frame": {"x":55,"y":0,"w":55,"h":54},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":55,"h":54},
			"sourceSize": {"w":55,"h":54}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "NSF-2B-G6 new box.png",
			"format": "RGBA8888",
			"size": {"w":110,"h":54},
			"scale": "1"
		}
		},
	

ScreenTextBox: {"frames": [

{
	"filename": "Symbol 14 instance 10000",
	"frame": {"x":0,"y":0,"w":159,"h":87},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":159,"h":87},
	"sourceSize": {"w":159,"h":87}
}
,{
	"filename": "Symbol 14 instance 10001",
	"frame": {"x":159,"y":0,"w":159,"h":87},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":159,"h":87},
	"sourceSize": {"w":159,"h":87}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "19.2.1.408",
	"image": "Box2.png.png",
	"format": "RGBA8888",
	"size": {"w":319,"h":87},
	"scale": "1"
}
},

comingUpJson: {"frames": [
{
	"filename": "Symbol 4 copy instance 10000",
	"frame": {"x":0,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10001",
	"frame": {"x":68,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10002",
	"frame": {"x":136,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10003",
	"frame": {"x":204,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10004",
	"frame": {"x":272,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10005",
	"frame": {"x":340,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10006",
	"frame": {"x":408,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10007",
	"frame": {"x":476,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10008",
	"frame": {"x":544,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10009",
	"frame": {"x":612,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10010",
	"frame": {"x":680,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10011",
	"frame": {"x":748,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10012",
	"frame": {"x":816,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "holding a fish coming back from water,.png",
	"format": "RGBA8888",
	"size": {"w":918,"h":72},
	"scale": "1"
}    
    
},
    
rightbutton:{"frames": [

		{
			"filename": "Symbol 10 instance 10000",
			"frame": {"x":0,"y":0,"w":68,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
			"sourceSize": {"w":68,"h":68}
		}
		,{
			"filename": "Symbol 10 instance 10001",
			"frame": {"x":68,"y":0,"w":68,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
			"sourceSize": {"w":68,"h":68}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "Right Btn.png",
			"format": "RGBA8888",
			"size": {"w":138,"h":70},
			"scale": "1"
		}
},

homebtnJson : {"frames": [

{
	"filename": "Symbol 4 instance 10000",
	"frame": {"x":0,"y":0,"w":60,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
	"sourceSize": {"w":60,"h":60}
}
,{
	"filename": "Symbol 4 instance 10001",
	"frame": {"x":0,"y":60,"w":60,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
	"sourceSize": {"w":60,"h":60}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "18.0.1.115",
	"image": "H.png",
	"format": "RGB8",
	"size": {"w":64,"h":128},
	"scale": "1"
}
},

nextbtnJson : {"frames": [

{
	"filename": "Symbol 6 instance 10000",
	"frame": {"x":0,"y":0,"w":59,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":59,"h":60},
	"sourceSize": {"w":59,"h":60}
}
,{
	"filename": "Symbol 6 instance 10001",
	"frame": {"x":0,"y":60,"w":59,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":59,"h":60},
	"sourceSize": {"w":59,"h":60}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "18.0.1.115",
	"image": "N.png",
	"format": "RGB8",
	"size": {"w":64,"h":128},
	"scale": "1"
}
},
SquareBoxJson:{"frames": [

	{
		"filename": "Symbol 5 instance 10000",
		"frame": {"x":0,"y":0,"w":55,"h":54},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":55,"h":54},
		"sourceSize": {"w":55,"h":54}
	}
	,{
		"filename": "Symbol 5 instance 10001",
		"frame": {"x":55,"y":0,"w":55,"h":54},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":55,"h":54},
		"sourceSize": {"w":55,"h":54}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "20.0.1.19255",
		"image": "NSF-2B-G6 new box.png",
		"format": "RGBA8888",
		"size": {"w":110,"h":54},
		"scale": "1"
	}
	},
	Rectangle9Json:{"frames": [

		{
			"filename": "Symbol 20 instance 10000",
			"frame": {"x":0,"y":0,"w":34,"h":72},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":34,"h":72},
			"sourceSize": {"w":34,"h":72}
		}
		,{
			"filename": "Symbol 20 instance 10001",
			"frame": {"x":34,"y":0,"w":34,"h":72},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":34,"h":72},
			"sourceSize": {"w":34,"h":72}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "1X9 rectangle small_1.png",
			"format": "RGBA8888",
			"size": {"w":69,"h":73},
			"scale": "1"
		}
	},
	Rectangle6Json:{"frames": [

		{
			"filename": "Symbol 27 instance 10000",
			"frame": {"x":0,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}
		,{
			"filename": "Symbol 27 instance 10001",
			"frame": {"x":45,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "1X6 rectangle small_1.png",
			"format": "RGBA8888",
			"size": {"w":91,"h":69},
			"scale": "1"
		}
	},
	Square4Json:{"frames": [

		{
			"filename": "Symbol 23 instance 10000",
			"frame": {"x":0,"y":0,"w":58,"h":57},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":58,"h":57},
			"sourceSize": {"w":58,"h":57}
		}
		,{
			"filename": "Symbol 23 instance 10001",
			"frame": {"x":58,"y":0,"w":58,"h":57},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":58,"h":57},
			"sourceSize": {"w":58,"h":57}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "1X4 square small_1.png",
			"format": "RGBA8888",
			"size": {"w":116,"h":57},
			"scale": "1"
		}
	},
	Circle11Json:{"frames": [

		{
			"filename": "Symbol 15 instance 10000",
			"frame": {"x":0,"y":0,"w":60,"h":60},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
			"sourceSize": {"w":60,"h":60}
		}
		,{
			"filename": "Symbol 15 instance 10001",
			"frame": {"x":60,"y":0,"w":60,"h":60},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
			"sourceSize": {"w":60,"h":60}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "1X4traypieces1.png",
			"format": "RGBA8888",
			"size": {"w":122,"h":61},
			"scale": "1"
		}	
		},
	Circle12Json:{"frames": [

		{
			"filename": "Symbol 16 instance 10000",
			"frame": {"x":0,"y":0,"w":60,"h":60},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
			"sourceSize": {"w":60,"h":60}
		}
		,{
			"filename": "Symbol 16 instance 10001",
			"frame": {"x":60,"y":0,"w":60,"h":60},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
			"sourceSize": {"w":60,"h":60}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "1X4traypieces2.png",
			"format": "RGBA8888",
			"size": {"w":122,"h":61},
			"scale": "1"
		}
		},
	Circle13Json:{"frames": [

		{
			"filename": "Symbol 17 instance 10000",
			"frame": {"x":0,"y":0,"w":60,"h":60},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
			"sourceSize": {"w":60,"h":60}
		}
		,{
			"filename": "Symbol 17 instance 10001",
			"frame": {"x":60,"y":0,"w":60,"h":60},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
			"sourceSize": {"w":60,"h":60}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "1X4traypieces3.png",
			"format": "RGBA8888",
			"size": {"w":122,"h":61},
			"scale": "1"
		}
		},
	Circle14Json:{"frames": [

		{
			"filename": "Symbol 18 instance 10000",
			"frame": {"x":0,"y":0,"w":60,"h":60},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
			"sourceSize": {"w":60,"h":60}
		}
		,{
			"filename": "Symbol 18 instance 10001",
			"frame": {"x":60,"y":0,"w":60,"h":60},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
			"sourceSize": {"w":60,"h":60}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "1X4traypieces4.png",
			"format": "RGBA8888",
			"size": {"w":122,"h":61},
			"scale": "1"
		}
	},
	tickJson : 
	{"frames": [

		{
			"filename": "Symbol 14 copy instance 10000",
			"frame": {"x":0,"y":0,"w":58,"h":61},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":0,"y":0,"w":64,"h":68},
			"sourceSize": {"w":64,"h":68}
		}
		,{
			"filename": "Symbol 14 copy instance 10001",
			"frame": {"x":58,"y":0,"w":59,"h":62},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":5,"y":6,"w":64,"h":68},
			"sourceSize": {"w":64,"h":68}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "right btn.png",
			"format": "RGB8",
			"size": {"w":121,"h":62},
			"scale": "1"
		}
	},

	oneThreeJson :
	{"frames": [

		{
			"filename": "Symbol 64 instance 10000",
			"frame": {"x":0,"y":0,"w":35,"h":55},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":35,"h":55},
			"sourceSize": {"w":35,"h":55}
		}
		,{
			"filename": "Symbol 64 instance 10001",
			"frame": {"x":35,"y":0,"w":35,"h":55},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":35,"h":55},
			"sourceSize": {"w":35,"h":55}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "1X3 sprit.png",
			"format": "RGBA8888",
			"size": {"w":70,"h":55},
			"scale": "1"
		}
	},
	
	oneFiveJson:
	{"frames": [

		{
			"filename": "Symbol 29 instance 10000",
			"frame": {"x":0,"y":0,"w":35,"h":55},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":35,"h":55},
			"sourceSize": {"w":35,"h":55}
		}
		,{
			"filename": "Symbol 29 instance 10001",
			"frame": {"x":35,"y":0,"w":35,"h":55},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":35,"h":55},
			"sourceSize": {"w":35,"h":55}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "1X5 sprit.png",
			"format": "RGBA8888",
			"size": {"w":70,"h":55},
			"scale": "1"
		}
	},

	oneSevenJson:
	{"frames": [

		{
			"filename": "Symbol 62 instance 10000",
			"frame": {"x":0,"y":0,"w":35,"h":54},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":35,"h":54},
			"sourceSize": {"w":35,"h":54}
		}
		,{
			"filename": "Symbol 62 instance 10001",
			"frame": {"x":35,"y":0,"w":35,"h":54},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":35,"h":54},
			"sourceSize": {"w":35,"h":54}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "1X7sprit.png",
			"format": "RGBA8888",
			"size": {"w":70,"h":55},
			"scale": "1"
		}
		},

	oneEightJson:
	{"frames": [

		{
			"filename": "Symbol 63 instance 10000",
			"frame": {"x":0,"y":0,"w":35,"h":54},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":35,"h":54},
			"sourceSize": {"w":35,"h":54}
		}
		,{
			"filename": "Symbol 63 instance 10001",
			"frame": {"x":35,"y":0,"w":35,"h":54},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":35,"h":54},
			"sourceSize": {"w":35,"h":54}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "1X8 sprit.png",
			"format": "RGBA8888",
			"size": {"w":70,"h":55},
			"scale": "1"
		}
		},
		basketJson :
		{"frames": [

			{
				"filename": "<Group>_13 instance 10000",
				"frame": {"x":0,"y":342,"w":168,"h":138},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":16,"y":16,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10001",
				"frame": {"x":198,"y":341,"w":196,"h":166},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":4,"y":4,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10002",
				"frame": {"x":0,"y":174,"w":198,"h":168},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":3,"y":3,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10003",
				"frame": {"x":204,"y":171,"w":200,"h":170},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":2,"y":2,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10004",
				"frame": {"x":0,"y":0,"w":204,"h":174},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10005",
				"frame": {"x":204,"y":0,"w":200,"h":171},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":2,"y":1,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10006",
				"frame": {"x":0,"y":174,"w":198,"h":168},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":3,"y":3,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10007",
				"frame": {"x":198,"y":341,"w":196,"h":166},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":4,"y":4,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10008",
				"frame": {"x":0,"y":174,"w":198,"h":168},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":3,"y":3,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10009",
				"frame": {"x":204,"y":171,"w":200,"h":170},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":2,"y":2,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10010",
				"frame": {"x":0,"y":0,"w":204,"h":174},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10011",
				"frame": {"x":204,"y":0,"w":200,"h":171},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":2,"y":1,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10012",
				"frame": {"x":0,"y":174,"w":198,"h":168},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":3,"y":3,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10013",
				"frame": {"x":198,"y":341,"w":196,"h":166},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":4,"y":4,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10014",
				"frame": {"x":0,"y":174,"w":198,"h":168},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":3,"y":3,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10015",
				"frame": {"x":204,"y":171,"w":200,"h":170},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":2,"y":2,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10016",
				"frame": {"x":0,"y":0,"w":204,"h":174},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10017",
				"frame": {"x":204,"y":0,"w":200,"h":171},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":2,"y":1,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10018",
				"frame": {"x":0,"y":174,"w":198,"h":168},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":3,"y":3,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10019",
				"frame": {"x":198,"y":341,"w":196,"h":166},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":4,"y":4,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10020",
				"frame": {"x":0,"y":174,"w":198,"h":168},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":3,"y":3,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10021",
				"frame": {"x":204,"y":171,"w":200,"h":170},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":2,"y":2,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10022",
				"frame": {"x":0,"y":0,"w":204,"h":174},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10023",
				"frame": {"x":204,"y":0,"w":200,"h":171},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":2,"y":1,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10024",
				"frame": {"x":0,"y":174,"w":198,"h":168},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":3,"y":3,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}
			,{
				"filename": "<Group>_13 instance 10025",
				"frame": {"x":198,"y":341,"w":196,"h":166},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":4,"y":4,"w":204,"h":174},
				"sourceSize": {"w":204,"h":174}
			}],
			"meta": {
				"app": "Adobe Animate",
				"version": "18.0.0.107",
				"image": "box2.png",
				"format": "RGBA8888",
				"size": {"w":512,"h":512},
				"scale": "1"
			}
			},
		CarotJson :
		{"frames": [

			{
				"filename": "<Group>_17 instance 10000",
				"frame": {"x":0,"y":296,"w":103,"h":20},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":15,"y":13,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10001",
				"frame": {"x":0,"y":248,"w":131,"h":48},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":3,"y":1,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10002",
				"frame": {"x":0,"y":150,"w":133,"h":49},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":2,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10003",
				"frame": {"x":0,"y":50,"w":135,"h":50},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":1,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10004",
				"frame": {"x":0,"y":0,"w":136,"h":50},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10005",
				"frame": {"x":0,"y":100,"w":135,"h":50},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":1,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10006",
				"frame": {"x":0,"y":199,"w":133,"h":49},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":2,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10007",
				"frame": {"x":0,"y":248,"w":131,"h":48},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":3,"y":1,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10008",
				"frame": {"x":0,"y":150,"w":133,"h":49},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":2,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10009",
				"frame": {"x":0,"y":50,"w":135,"h":50},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":1,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10010",
				"frame": {"x":0,"y":0,"w":136,"h":50},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10011",
				"frame": {"x":0,"y":100,"w":135,"h":50},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":1,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10012",
				"frame": {"x":0,"y":199,"w":133,"h":49},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":2,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10013",
				"frame": {"x":0,"y":248,"w":131,"h":48},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":3,"y":1,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10014",
				"frame": {"x":0,"y":150,"w":133,"h":49},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":2,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10015",
				"frame": {"x":0,"y":50,"w":135,"h":50},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":1,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10016",
				"frame": {"x":0,"y":0,"w":136,"h":50},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10017",
				"frame": {"x":0,"y":100,"w":135,"h":50},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":1,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10018",
				"frame": {"x":0,"y":199,"w":133,"h":49},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":2,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10019",
				"frame": {"x":0,"y":248,"w":131,"h":48},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":3,"y":1,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10020",
				"frame": {"x":0,"y":150,"w":133,"h":49},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":2,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10021",
				"frame": {"x":0,"y":50,"w":135,"h":50},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":1,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10022",
				"frame": {"x":0,"y":0,"w":136,"h":50},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10023",
				"frame": {"x":0,"y":100,"w":135,"h":50},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":1,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10024",
				"frame": {"x":0,"y":199,"w":133,"h":49},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":2,"y":0,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}
			,{
				"filename": "<Group>_17 instance 10025",
				"frame": {"x":0,"y":248,"w":131,"h":48},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":3,"y":1,"w":136,"h":50},
				"sourceSize": {"w":136,"h":50}
			}],
			"meta": {
				"app": "Adobe Animate",
				"version": "18.0.0.107",
				"image": "caroot.png",
				"format": "RGBA8888",
				"size": {"w":256,"h":512},
				"scale": "1"
			}
			},
			appleJson :
			{"frames": [

				{
					"filename": "<Group>_23 instance 10000",
					"frame": {"x":0,"y":363,"w":159,"h":91},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":16,"y":14,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10001",
					"frame": {"x":190,"y":244,"w":187,"h":119},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":4,"y":2,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10002",
					"frame": {"x":0,"y":124,"w":190,"h":120},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":3,"y":2,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10003",
					"frame": {"x":195,"y":0,"w":192,"h":122},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":2,"y":1,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10004",
					"frame": {"x":0,"y":0,"w":195,"h":124},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10005",
					"frame": {"x":195,"y":122,"w":192,"h":122},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":2,"y":1,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10006",
					"frame": {"x":0,"y":244,"w":190,"h":119},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":3,"y":2,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10007",
					"frame": {"x":190,"y":244,"w":187,"h":119},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":4,"y":2,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10008",
					"frame": {"x":0,"y":124,"w":190,"h":120},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":3,"y":2,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10009",
					"frame": {"x":195,"y":0,"w":192,"h":122},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":2,"y":1,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10010",
					"frame": {"x":0,"y":0,"w":195,"h":124},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10011",
					"frame": {"x":195,"y":122,"w":192,"h":122},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":2,"y":1,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10012",
					"frame": {"x":0,"y":244,"w":190,"h":119},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":3,"y":2,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10013",
					"frame": {"x":190,"y":244,"w":187,"h":119},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":4,"y":2,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10014",
					"frame": {"x":0,"y":124,"w":190,"h":120},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":3,"y":2,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10015",
					"frame": {"x":195,"y":0,"w":192,"h":122},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":2,"y":1,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10016",
					"frame": {"x":0,"y":0,"w":195,"h":124},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10017",
					"frame": {"x":195,"y":122,"w":192,"h":122},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":2,"y":1,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10018",
					"frame": {"x":0,"y":244,"w":190,"h":119},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":3,"y":2,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10019",
					"frame": {"x":190,"y":244,"w":187,"h":119},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":4,"y":2,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10020",
					"frame": {"x":0,"y":124,"w":190,"h":120},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":3,"y":2,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10021",
					"frame": {"x":195,"y":0,"w":192,"h":122},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":2,"y":1,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10022",
					"frame": {"x":0,"y":0,"w":195,"h":124},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10023",
					"frame": {"x":195,"y":122,"w":192,"h":122},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":2,"y":1,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10024",
					"frame": {"x":0,"y":244,"w":190,"h":119},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":3,"y":2,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}
				,{
					"filename": "<Group>_23 instance 10025",
					"frame": {"x":190,"y":244,"w":187,"h":119},
					"rotated": false,
					"trimmed": true,
					"spriteSourceSize": {"x":4,"y":2,"w":195,"h":124},
					"sourceSize": {"w":195,"h":124}
				}],
				"meta": {
					"app": "Adobe Animate",
					"version": "18.0.0.107",
					"image": "pappaya.png",
					"format": "RGBA8888",
					"size": {"w":431,"h":835},
					"scale": "1"
				}
				},

				BallJson :
				{"frames": [

					{
						"filename": "<Group>_13 instance 10000",
						"frame": {"x":171,"y":0,"w":55,"h":56},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":14,"y":13,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10001",
						"frame": {"x":170,"y":84,"w":83,"h":84},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":2,"y":1,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10002",
						"frame": {"x":86,"y":0,"w":85,"h":84},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":1,"y":1,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10003",
						"frame": {"x":0,"y":86,"w":85,"h":85},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":1,"y":0,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10004",
						"frame": {"x":0,"y":0,"w":86,"h":86},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10005",
						"frame": {"x":85,"y":86,"w":85,"h":85},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":1,"y":0,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10006",
						"frame": {"x":86,"y":0,"w":85,"h":84},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":1,"y":1,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10007",
						"frame": {"x":170,"y":84,"w":83,"h":84},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":2,"y":1,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10008",
						"frame": {"x":86,"y":0,"w":85,"h":84},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":1,"y":1,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10009",
						"frame": {"x":0,"y":86,"w":85,"h":85},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":1,"y":0,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10010",
						"frame": {"x":0,"y":0,"w":86,"h":86},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10011",
						"frame": {"x":85,"y":86,"w":85,"h":85},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":1,"y":0,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10012",
						"frame": {"x":86,"y":0,"w":85,"h":84},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":1,"y":1,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10013",
						"frame": {"x":170,"y":84,"w":83,"h":84},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":2,"y":1,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10014",
						"frame": {"x":86,"y":0,"w":85,"h":84},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":1,"y":1,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10015",
						"frame": {"x":0,"y":86,"w":85,"h":85},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":1,"y":0,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10016",
						"frame": {"x":0,"y":0,"w":86,"h":86},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10017",
						"frame": {"x":85,"y":86,"w":85,"h":85},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":1,"y":0,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10018",
						"frame": {"x":86,"y":0,"w":85,"h":84},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":1,"y":1,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10019",
						"frame": {"x":170,"y":84,"w":83,"h":84},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":2,"y":1,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10020",
						"frame": {"x":86,"y":0,"w":85,"h":84},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":1,"y":1,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10021",
						"frame": {"x":0,"y":86,"w":85,"h":85},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":1,"y":0,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10022",
						"frame": {"x":0,"y":0,"w":86,"h":86},
						"rotated": false,
						"trimmed": false,
						"spriteSourceSize": {"x":0,"y":0,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10023",
						"frame": {"x":85,"y":86,"w":85,"h":85},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":1,"y":0,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10024",
						"frame": {"x":86,"y":0,"w":85,"h":84},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":1,"y":1,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}
					,{
						"filename": "<Group>_13 instance 10025",
						"frame": {"x":170,"y":84,"w":83,"h":84},
						"rotated": false,
						"trimmed": true,
						"spriteSourceSize": {"x":2,"y":1,"w":86,"h":86},
						"sourceSize": {"w":86,"h":86}
					}],
					"meta": {
						"app": "Adobe Animate",
						"version": "18.0.0.107",
						"image": "Ball.png",
						"format": "RGBA8888",
						"size": {"w":256,"h":256},
						"scale": "1"
					}
					},

					bulbBtnJson	: {"frames": [

						{
							"filename": "Symbol 1 instance 10000",
							"frame": {"x":0,"y":0,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10001",
							"frame": {"x":66,"y":0,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10002",
							"frame": {"x":132,"y":0,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10003",
							"frame": {"x":0,"y":49,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10004",
							"frame": {"x":66,"y":49,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10005",
							"frame": {"x":132,"y":49,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10006",
							"frame": {"x":0,"y":98,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10007",
							"frame": {"x":66,"y":98,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10008",
							"frame": {"x":132,"y":98,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10009",
							"frame": {"x":0,"y":147,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10010",
							"frame": {"x":66,"y":147,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10011",
							"frame": {"x":132,"y":147,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10012",
							"frame": {"x":0,"y":196,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10013",
							"frame": {"x":66,"y":196,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10014",
							"frame": {"x":132,"y":196,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10015",
							"frame": {"x":0,"y":245,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10016",
							"frame": {"x":66,"y":245,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10017",
							"frame": {"x":132,"y":245,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}
						,{
							"filename": "Symbol 1 instance 10018",
							"frame": {"x":0,"y":294,"w":66,"h":49},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
							"sourceSize": {"w":66,"h":49}
						}],
						"meta": {
							"app": "Adobe Animate",
							"version": "18.0.0.107",
							"image": "bulb anim.png",
							"format": "RGBA8888",
							"size": {"w":198,"h":347},
							"scale": "1"
						}
					},
					
					devideSign :{"frames": [

						{
							"filename": "Symbol 2 instance 10000",
							"frame": {"x":0,"y":0,"w":92,"h":90},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":92,"h":90},
							"sourceSize": {"w":92,"h":90}
						}
						,{
							"filename": "Symbol 2 instance 10001",
							"frame": {"x":92,"y":0,"w":92,"h":90},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":92,"h":90},
							"sourceSize": {"w":92,"h":90}
						}],
						"meta": {
							"app": "Adobe Animate",
							"version": "22.0.0.93",
							"image": "symbol_1.png",
							"format": "RGBA8888",
							"size": {"w":184,"h":90},
							"scale": "1"
						}
						},

					flipbtnJson :{"frames": [

						{
							"filename": "Symbol 13 copy 2 instance 10000",
							"frame": {"x":0,"y":0,"w":91,"h":90},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":91,"h":90},
							"sourceSize": {"w":91,"h":90}
						}
						,{
							"filename": "Symbol 13 copy 2 instance 10001",
							"frame": {"x":91,"y":0,"w":91,"h":90},
							"rotated": false,
							"trimmed": false,
							"spriteSourceSize": {"x":0,"y":0,"w":91,"h":90},
							"sourceSize": {"w":91,"h":90}
						}],
						"meta": {
							"app": "Adobe Animate",
							"version": "22.0.0.93",
							"image": "symbol_3.png",
							"format": "RGBA8888",
							"size": {"w":183,"h":90},
							"scale": "1"
						}
						},
						
						numberPad: {
							"frames": [
					
								{
									"filename": "Symbol 3 instance 10000",
									"frame": { "x": 0, "y": 0, "w": 68, "h": 68 },
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
									"sourceSize": { "w": 68, "h": 68 }
								}
								, {
									"filename": "Symbol 3 instance 10001",
									"frame": { "x": 68, "y": 0, "w": 68, "h": 68 },
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
									"sourceSize": { "w": 68, "h": 68 }
								}
								, {
									"filename": "Symbol 3 instance 10002",
									"frame": { "x": 136, "y": 0, "w": 68, "h": 68 },
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
									"sourceSize": { "w": 68, "h": 68 }
								}
								, {
									"filename": "Symbol 3 instance 10003",
									"frame": { "x": 204, "y": 0, "w": 68, "h": 68 },
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
									"sourceSize": { "w": 68, "h": 68 }
								}
								, {
									"filename": "Symbol 3 instance 10004",
									"frame": { "x": 272, "y": 0, "w": 68, "h": 68 },
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
									"sourceSize": { "w": 68, "h": 68 }
								}
								, {
									"filename": "Symbol 3 instance 10005",
									"frame": { "x": 340, "y": 0, "w": 68, "h": 68 },
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
									"sourceSize": { "w": 68, "h": 68 }
								}
								, {
									"filename": "Symbol 3 instance 10006",
									"frame": { "x": 408, "y": 0, "w": 68, "h": 68 },
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
									"sourceSize": { "w": 68, "h": 68 }
								}
								, {
									"filename": "Symbol 3 instance 10007",
									"frame": { "x": 476, "y": 0, "w": 68, "h": 68 },
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
									"sourceSize": { "w": 68, "h": 68 }
								}
								, {
									"filename": "Symbol 3 instance 10008",
									"frame": { "x": 544, "y": 0, "w": 68, "h": 68 },
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
									"sourceSize": { "w": 68, "h": 68 }
								}
								, {
									"filename": "Symbol 3 instance 10009",
									"frame": { "x": 612, "y": 0, "w": 68, "h": 68 },
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
									"sourceSize": { "w": 68, "h": 68 }
								}
								, {
									"filename": "Symbol 3 instance 10010",
									"frame": { "x": 680, "y": 0, "w": 68, "h": 68 },
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
									"sourceSize": { "w": 68, "h": 68 }
								}
								, {
									"filename": "Symbol 3 instance 10011",
									"frame": { "x": 748, "y": 0, "w": 68, "h": 68 },
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
									"sourceSize": { "w": 68, "h": 68 }
								}
								, {
									"filename": "Symbol 3 instance 10012",
									"frame": { "x": 816, "y": 0, "w": 68, "h": 68 },
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
									"sourceSize": { "w": 68, "h": 68 }
								}
								, {
									"filename": "Symbol 3 instance 10013",
									"frame": { "x": 884, "y": 0, "w": 68, "h": 68 },
									"rotated": false,
									"trimmed": false,
									"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
									"sourceSize": { "w": 68, "h": 68 }
								}],
							"meta": {
								"app": "Adobe Animate",
								"version": "20.0.1.19255",
								"image": "number 0 to 9.png",
								"format": "RGBA8888",
								"size": { "w": 953, "h": 68 },
								"scale": "1"
							}
						},
						
								
};


