Game.preloader_AL_ADD_G7=function(game){
	this.preloadBar=null;
};
        
var chime,clockTick;
Game.preloader_AL_ADD_G7.prototype={
	preload:function(){
        this.load.video('aladdg7','demoVideos/AL-ADD-G7.mp4');   //* include demo video of game.
        this.load.image('skipArrow','assets/commonAssets/skipArrow.png');
        
        this.load.atlas('bulb','assets/commonAssets/bulb.png',null,AL_ADD_G7_JSON.bulbBtnJson);
        
	this.load.atlas('backbtn','assets/commonAssets/backbtn.png' ,null,AL_ADD_G7_JSON.backbtnJson);
        this.load.atlas('CommonSpeakerBtn','assets/commonAssets/speaker.png' ,null,AL_ADD_G7_JSON.speakerJson);
        this.load.atlas('starAnim','assets/commonAssets/starAnim.png',null,AL_ADD_G7_JSON.starAnimJson);
        this.load.atlas('replay','assets/commonAssets/reply.png' ,null,AL_ADD_G7_JSON.replyJson);

        //this.load.atlas('allColor','assets/gradeAssets/AL-ADD-G7/all colour new.png' ,null,AL_ADD_G7_JSON.allColorJson);
        
        this.load.image('navBar','assets/commonAssets/navBar.png');
        this.load.image('timebg','assets/commonAssets/timebg.png');
        this.load.image('hand','assets/commonAssets/hand.png');

        this.load.atlas('reverse',' assets/gradeAssets/AL-ADD-G7/Btn_1.png',null,AL_ADD_G7_JSON.btn_1Json);

        this.load.atlas('CommonHomeBtn','assets/commonAssets/homeBtn.png', null, AL_ADD_G7_JSON.homebtnJson);
        this.load.atlas('CommonNextBtn','assets/commonAssets/nextBtn.png', null, AL_ADD_G7_JSON.nextbtnJson);

        this.load.atlas('symbol_1','assets/gradeAssets/AL-ADD-G7/symbol_1.png', null, AL_ADD_G7_JSON.symbol1Json);
        this.load.atlas('symbol_2','assets/gradeAssets/AL-ADD-G7/symbol_2.png', null, AL_ADD_G7_JSON.symbol2Json);
        this.load.atlas('symbol_3','assets/gradeAssets/AL-ADD-G7/symbol_3.png', null, AL_ADD_G7_JSON.symbol3Json);

        this.load.atlas('eraser','assets/gradeAssets/AL-ADD-G7/Btn_2.png', null, AL_ADD_G7_JSON.eraserJson);

       // this.load.atlas('allColor','assets/gradeAssets/AL-ADD-G7/all colour new.png', null, AL_ADD_G7_JSON.allColorJson); 
        
        this.load.image('BG1', 'assets/gradeAssets/AL-ADD-G7/Bg.png');
        this.load.image('Textbox_1', 'assets/gradeAssets/AL-ADD-G7/Text box_1.png');

        this.load.image('Text box_4', 'assets/gradeAssets/AL-ADD-G7/text box_4.png'); 
        
        this.load.image('Text box_3', 'assets/gradeAssets/AL-ADD-G7/text box3.png');
      //  this.load.image('box_3', 'assets/gradeAssets/AL-ADD-G7/box_3.png');
       // this.load.image('box_1', 'assets/gradeAssets/AL-ADD-G7/box_1.png');
        this.load.image('box_2', 'assets/gradeAssets/AL-ADD-G7/box_2.png');

        this.load.image('hand', 'assets/commonAssets/hand.png');

        this.load.image('Text box_1', 'assets/gradeAssets/AL-ADD-G7/text box_1.png');
        this.load.image('Text box_2', 'assets/gradeAssets/AL-ADD-G7/text box_2.png');
        
        this.load.atlas('Text box_5', 'assets/gradeAssets/AL-ADD-G7/text box_5.png', null, AL_ADD_G7_JSON.answerBoxJson);

        this.load.image('panale_1', 'assets/gradeAssets/AL-ADD-G7/panale_1.png');
        this.load.image('panale_2', 'assets/gradeAssets/AL-ADD-G7/panale_2.png');
        this.load.image('panale_3', 'assets/gradeAssets/AL-ADD-G7/panale_3.png');
        this.load.image('panale_4', 'assets/gradeAssets/AL-ADD-G7/panale_4.png');

        this.load.image('green_1', 'assets/gradeAssets/AL-ADD-G7/green_1.png');
        this.load.image('green_2', 'assets/gradeAssets/AL-ADD-G7/green_2.png');
        this.load.image('green_3', 'assets/gradeAssets/AL-ADD-G7/green_3.png');

        this.load.image('pink_1', 'assets/gradeAssets/AL-ADD-G7/pink_1.png');
        this.load.image('pink_2', 'assets/gradeAssets/AL-ADD-G7/pink_2.png');
        this.load.image('pink_3', 'assets/gradeAssets/AL-ADD-G7/pink_3.png');

        this.load.image('yellow box', 'assets/gradeAssets/AL-ADD-G7/yellow box_1.png');

        this.load.atlas('TickBtn', 'assets/gradeAssets/AL-ADD-G7/TickBtn.png', null, AL_ADD_G7_JSON.tickJson);

        this.load.image('numpadbg','assets/gradeAssets/AL-ADD-G7/numbg.png');
        this.load.atlas('Numberpad','assets/gradeAssets/AL-ADD-G7/number pad.png',null,AL_ADD_G7_JSON.numberpadJson);
        },

	create:function(){
		
		this.state.start('AL_ADD_G7level1');   
    },
}