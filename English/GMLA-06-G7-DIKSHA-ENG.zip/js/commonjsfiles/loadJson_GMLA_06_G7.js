var GMLA_06_G7_JSON = {
	starAnimJson: {
		"frames": [

			{
				"filename": "Symbol 10 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10001",
				"frame": { "x": 0, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10002",
				"frame": { "x": 0, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10003",
				"frame": { "x": 0, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10004",
				"frame": { "x": 33, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10005",
				"frame": { "x": 33, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10006",
				"frame": { "x": 33, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10007",
				"frame": { "x": 33, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10008",
				"frame": { "x": 66, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10009",
				"frame": { "x": 66, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10010",
				"frame": { "x": 66, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10011",
				"frame": { "x": 66, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10012",
				"frame": { "x": 99, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10013",
				"frame": { "x": 99, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10014",
				"frame": { "x": 99, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10015",
				"frame": { "x": 99, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10016",
				"frame": { "x": 132, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10017",
				"frame": { "x": 132, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10018",
				"frame": { "x": 132, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10019",
				"frame": { "x": 132, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10020",
				"frame": { "x": 165, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10021",
				"frame": { "x": 165, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10022",
				"frame": { "x": 165, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10023",
				"frame": { "x": 165, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10024",
				"frame": { "x": 198, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10025",
				"frame": { "x": 198, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10026",
				"frame": { "x": 198, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10027",
				"frame": { "x": 198, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10028",
				"frame": { "x": 231, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10029",
				"frame": { "x": 231, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10030",
				"frame": { "x": 231, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10031",
				"frame": { "x": 231, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10032",
				"frame": { "x": 264, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10033",
				"frame": { "x": 264, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10034",
				"frame": { "x": 264, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10035",
				"frame": { "x": 264, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "st.png",
			"format": "RGB8",
			"size": { "w": 334, "h": 479 },
			"scale": "1"
		}
	},

	speakerJson: {
		"frames": [

			{
				"filename": "Symbol 5 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"sourceSize": { "w": 41, "h": 30 }
			},
			{
				"filename": "Symbol 5 instance 10001",
				"frame": { "x": 0, "y": 30, "w": 41, "h": 30 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"sourceSize": { "w": 41, "h": 30 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "s.png",
			"format": "RGB8",
			"size": { "w": 44, "h": 64 },
			"scale": "1"
		}
	},

	btnJson: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"sourceSize": { "w": 212, "h": 71 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 0, "y": 71, "w": 212, "h": 71 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"sourceSize": { "w": 212, "h": 71 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "16.5.1.104",
			"image": "b1.png",
			"format": "RGB8",
			"size": { "w": 213, "h": 144 },
			"scale": "1"
		}
	},

	replyJson: {
		"frames": [

			{
				"filename": "Symbol 8 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}
			, {
				"filename": "Symbol 8 instance 10001",
				"frame": { "x": 47, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}
			, {
				"filename": "Symbol 8 instance 10002",
				"frame": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "Back btn.png",
			"format": "RGBA8888",
			"size": { "w": 98, "h": 48 },
			"scale": "1"
		}
	},

	backbtnJson: {
		"frames": [

			{
				"filename": "Symbol 9 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"sourceSize": { "w": 41, "h": 29 }
			}
			, {
				"filename": "Symbol 9 instance 10001",
				"frame": { "x": 0, "y": 29, "w": 41, "h": 29 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"sourceSize": { "w": 41, "h": 29 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "back.png",
			"format": "RGB8",
			"size": { "w": 44, "h": 64 },
			"scale": "1"
		}
	},

	tickJson: {
		"frames": [

			{
				"filename": "Symbol 10 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 68, "h": 66 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 66 },
				"sourceSize": { "w": 68, "h": 66 }
			}
			, {
				"filename": "Symbol 10 copy instance 10001",
				"frame": { "x": 68, "y": 0, "w": 68, "h": 66 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 66 },
				"sourceSize": { "w": 68, "h": 66 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "Right btn0002.png",
			"format": "RGBA8888",
			"size": { "w": 138, "h": 66 },
			"scale": "1"
		}
	},


	nextbtnJson: {
		"frames": [

			{
				"filename": "Symbol 6 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"sourceSize": { "w": 59, "h": 60 }
			}
			, {
				"filename": "Symbol 6 instance 10001",
				"frame": { "x": 0, "y": 60, "w": 59, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"sourceSize": { "w": 59, "h": 60 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.1.115",
			"image": "N.png",
			"format": "RGB8",
			"size": { "w": 64, "h": 128 },
			"scale": "1"
		}
	},
	homebtnJson: {
		"frames": [

			{
				"filename": "Symbol 4 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"sourceSize": { "w": 60, "h": 60 }
			}
			, {
				"filename": "Symbol 4 instance 10001",
				"frame": { "x": 0, "y": 60, "w": 60, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"sourceSize": { "w": 60, "h": 60 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.1.115",
			"image": "H.png",
			"format": "RGB8",
			"size": { "w": 64, "h": 128 },
			"scale": "1"
		}

	},

	TickbtnJson: {
		"frames": [

			{
				"filename": "Symbol 10 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 67, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 67, "h": 68 },
				"sourceSize": { "w": 67, "h": 68 }
			}
			, {
				"filename": "Symbol 10 instance 10001",
				"frame": { "x": 67, "y": 0, "w": 67, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 67, "h": 68 },
				"sourceSize": { "w": 67, "h": 68 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "ALP-01-G6.png",
			"format": "RGBA8888",
			"size": { "w": 134, "h": 68 },
			"scale": "1"
		}
	},

	bulbBtnJson: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 66, "y": 0, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10002",
				"frame": { "x": 132, "y": 0, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10003",
				"frame": { "x": 0, "y": 49, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10004",
				"frame": { "x": 66, "y": 49, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10005",
				"frame": { "x": 132, "y": 49, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10006",
				"frame": { "x": 0, "y": 98, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10007",
				"frame": { "x": 66, "y": 98, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10008",
				"frame": { "x": 132, "y": 98, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10009",
				"frame": { "x": 0, "y": 147, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10010",
				"frame": { "x": 66, "y": 147, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10011",
				"frame": { "x": 132, "y": 147, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10012",
				"frame": { "x": 0, "y": 196, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10013",
				"frame": { "x": 66, "y": 196, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10014",
				"frame": { "x": 132, "y": 196, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10015",
				"frame": { "x": 0, "y": 245, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10016",
				"frame": { "x": 66, "y": 245, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10017",
				"frame": { "x": 132, "y": 245, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10018",
				"frame": { "x": 0, "y": 294, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "bulb anim.png",
			"format": "RGBA8888",
			"size": { "w": 198, "h": 347 },
			"scale": "1"
		}
	},

	box: {
		"frames": [

			{
				"filename": "Symbol 32 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 386, "h": 229 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 386, "h": 229 },
				"sourceSize": { "w": 386, "h": 229 }
			}
			, {
				"filename": "Symbol 32 instance 10001",
				"frame": { "x": 386, "y": 0, "w": 386, "h": 229 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 386, "h": 229 },
				"sourceSize": { "w": 386, "h": 229 }
			}
			, {
				"filename": "Symbol 32 instance 10002",
				"frame": { "x": 772, "y": 0, "w": 386, "h": 229 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 386, "h": 229 },
				"sourceSize": { "w": 386, "h": 229 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "3 box.png",
			"format": "RGBA8888",
			"size": { "w": 1163, "h": 232 },
			"scale": "1"
		}
	},

	colore_tex_box: {
		"frames": [
			{
				"filename": "Symbol 35 instance 10000",
				"frame": {
					"x": 0,
					"y": 0,
					"w": 50,
					"h": 51
				},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {
					"x": 0,
					"y": 0,
					"w": 50,
					"h": 51
				},
				"sourceSize": {
					"w": 50,
					"h": 51
				}
			},
			{
				"filename": "Symbol 35 instance 10001",
				"frame": {
					"x": 50,
					"y": 0,
					"w": 50,
					"h": 51
				},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {
					"x": 0,
					"y": 0,
					"w": 50,
					"h": 51
				},
				"sourceSize": {
					"w": 50,
					"h": 51
				}
			},
			{
				"filename": "Symbol 35 instance 10002",
				"frame": {
					"x": 100,
					"y": 0,
					"w": 50,
					"h": 51
				},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {
					"x": 0,
					"y": 0,
					"w": 50,
					"h": 51
				},
				"sourceSize": {
					"w": 50,
					"h": 51
				}
			}
		],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "3 colore tex box.png",
			"format": "RGBA8888",
			"size": {
				"w": 153,
				"h": 53
			},
			"scale": "1"
		}
	},
	pizza_anim: {
		"frames": [

			{
				"filename": "Symbol 42 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 306, "h": 241 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 306, "h": 241 },
				"sourceSize": { "w": 306, "h": 241 }
			}
			, {
				"filename": "Symbol 42 instance 10001",
				"frame": { "x": 306, "y": 0, "w": 306, "h": 241 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 306, "h": 241 },
				"sourceSize": { "w": 306, "h": 241 }
			}
			, {
				"filename": "Symbol 42 instance 10002",
				"frame": { "x": 612, "y": 0, "w": 306, "h": 241 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 306, "h": 241 },
				"sourceSize": { "w": 306, "h": 241 }
			}
			, {
				"filename": "Symbol 42 instance 10003",
				"frame": { "x": 918, "y": 0, "w": 306, "h": 241 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 306, "h": 241 },
				"sourceSize": { "w": 306, "h": 241 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "pizza anim.png",
			"format": "RGBA8888",
			"size": { "w": 1233, "h": 256 },
			"scale": "1"
		}
	},
	numberpadJson: {
		"frames": [

			{
				"filename": "Symbol 11 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10001",
				"frame": { "x": 49, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10002",
				"frame": { "x": 98, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10003",
				"frame": { "x": 147, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10004",
				"frame": { "x": 196, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10005",
				"frame": { "x": 245, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10006",
				"frame": { "x": 294, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10007",
				"frame": { "x": 343, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10008",
				"frame": { "x": 392, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10009",
				"frame": { "x": 441, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10010",
				"frame": { "x": 490, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10011",
				"frame": { "x": 539, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10012",
				"frame": { "x": 588, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.4.185",
			"image": "number pad.png",
			"format": "RGBA8888",
			"size": { "w": 637, "h": 49 },
			"scale": "1"
		}
	},
	biscuitanim: {
		"frames": [

			{
				"filename": "Symbol 44 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 173, "h": 151 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 173, "h": 151 },
				"sourceSize": { "w": 173, "h": 151 }
			}
			, {
				"filename": "Symbol 44 instance 10001",
				"frame": { "x": 173, "y": 0, "w": 173, "h": 151 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 173, "h": 151 },
				"sourceSize": { "w": 173, "h": 151 }
			}
			, {
				"filename": "Symbol 44 instance 10002",
				"frame": { "x": 346, "y": 0, "w": 173, "h": 151 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 173, "h": 151 },
				"sourceSize": { "w": 173, "h": 151 }
			}
			, {
				"filename": "Symbol 44 instance 10003",
				"frame": { "x": 519, "y": 0, "w": 173, "h": 151 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 173, "h": 151 },
				"sourceSize": { "w": 173, "h": 151 }
			}
			, {
				"filename": "Symbol 44 instance 10004",
				"frame": { "x": 692, "y": 0, "w": 173, "h": 151 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 173, "h": 151 },
				"sourceSize": { "w": 173, "h": 151 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "biscuit.png",
			"format": "RGBA8888",
			"size": { "w": 866, "h": 160 },
			"scale": "1"
		}
	},
	cheeseanim: {
		"frames": [

			{
				"filename": "Symbol 45 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 156, "h": 153 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 156, "h": 153 },
				"sourceSize": { "w": 156, "h": 153 }
			}
			, {
				"filename": "Symbol 45 copy instance 10001",
				"frame": { "x": 156, "y": 0, "w": 156, "h": 153 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 156, "h": 153 },
				"sourceSize": { "w": 156, "h": 153 }
			}
			, {
				"filename": "Symbol 45 copy instance 10002",
				"frame": { "x": 312, "y": 0, "w": 156, "h": 153 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 156, "h": 153 },
				"sourceSize": { "w": 156, "h": 153 }
			}
			, {
				"filename": "Symbol 45 copy instance 10003",
				"frame": { "x": 468, "y": 0, "w": 156, "h": 153 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 156, "h": 153 },
				"sourceSize": { "w": 156, "h": 153 }
			}
			, {
				"filename": "Symbol 45 copy instance 10004",
				"frame": { "x": 624, "y": 0, "w": 156, "h": 153 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 156, "h": 153 },
				"sourceSize": { "w": 156, "h": 153 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "cheeseanim.png",
			"format": "RGBA8888",
			"size": { "w": 783, "h": 160 },
			"scale": "1"
		}
	},
	sandwichanim: {
		"frames": [

			{
				"filename": "Symbol 45 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 196, "h": 121 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 196, "h": 121 },
				"sourceSize": { "w": 196, "h": 121 }
			}
			, {
				"filename": "Symbol 45 instance 10001",
				"frame": { "x": 196, "y": 0, "w": 196, "h": 121 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 196, "h": 121 },
				"sourceSize": { "w": 196, "h": 121 }
			}
			, {
				"filename": "Symbol 45 instance 10002",
				"frame": { "x": 392, "y": 0, "w": 196, "h": 121 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 196, "h": 121 },
				"sourceSize": { "w": 196, "h": 121 }
			}
			, {
				"filename": "Symbol 45 instance 10003",
				"frame": { "x": 588, "y": 0, "w": 196, "h": 121 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 196, "h": 121 },
				"sourceSize": { "w": 196, "h": 121 }
			}
			, {
				"filename": "Symbol 45 instance 10004",
				"frame": { "x": 784, "y": 0, "w": 196, "h": 121 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 196, "h": 121 },
				"sourceSize": { "w": 196, "h": 121 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "sandwichanim.png",
			"format": "RGBA8888",
			"size": { "w": 999, "h": 160 },
			"scale": "1"
		}
	},
	wafferanim: {
		"frames": [

			{
				"filename": "Symbol 45 copy 2 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 151, "h": 157 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 151, "h": 157 },
				"sourceSize": { "w": 151, "h": 157 }
			}
			, {
				"filename": "Symbol 45 copy 2 instance 10001",
				"frame": { "x": 151, "y": 0, "w": 151, "h": 157 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 151, "h": 157 },
				"sourceSize": { "w": 151, "h": 157 }
			}
			, {
				"filename": "Symbol 45 copy 2 instance 10002",
				"frame": { "x": 302, "y": 0, "w": 151, "h": 157 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 151, "h": 157 },
				"sourceSize": { "w": 151, "h": 157 }
			}
			, {
				"filename": "Symbol 45 copy 2 instance 10003",
				"frame": { "x": 453, "y": 0, "w": 151, "h": 157 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 151, "h": 157 },
				"sourceSize": { "w": 151, "h": 157 }
			}
			, {
				"filename": "Symbol 45 copy 2 instance 10004",
				"frame": { "x": 604, "y": 0, "w": 151, "h": 157 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 151, "h": 157 },
				"sourceSize": { "w": 151, "h": 157 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "wafferanim.png",
			"format": "RGBA8888",
			"size": { "w": 755, "h": 160 },
			"scale": "1"
		}
	},
	watermelonanim: {
		"frames": [

			{
				"filename": "Symbol 45 copy 3 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 241, "h": 152 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 241, "h": 152 },
				"sourceSize": { "w": 241, "h": 152 }
			}
			, {
				"filename": "Symbol 45 copy 3 instance 10001",
				"frame": { "x": 241, "y": 0, "w": 241, "h": 152 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 241, "h": 152 },
				"sourceSize": { "w": 241, "h": 152 }
			}
			, {
				"filename": "Symbol 45 copy 3 instance 10002",
				"frame": { "x": 482, "y": 0, "w": 241, "h": 152 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 241, "h": 152 },
				"sourceSize": { "w": 241, "h": 152 }
			}
			, {
				"filename": "Symbol 45 copy 3 instance 10003",
				"frame": { "x": 723, "y": 0, "w": 241, "h": 152 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 241, "h": 152 },
				"sourceSize": { "w": 241, "h": 152 }
			}
			, {
				"filename": "Symbol 45 copy 3 instance 10004",
				"frame": { "x": 964, "y": 0, "w": 241, "h": 152 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 241, "h": 152 },
				"sourceSize": { "w": 241, "h": 152 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "watermelonanim.png",
			"format": "RGBA8888",
			"size": { "w": 1213, "h": 160 },
			"scale": "1"
		}
	},




};

