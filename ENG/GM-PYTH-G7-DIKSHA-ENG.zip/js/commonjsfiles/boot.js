var Game={};
Game.boot=function(Game){

};
var defaultLanguage = 'en';


Game.boot.prototype={
	init:function(){

		this.input.maxPointers=1;
		this.input.mouse.enabled = false;

		this.stage.disableVisibilityChange=true;

	},

	preload:function(){
		 
        
	},
	create:function(){

		this.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
        this.scale.pageAlignHorizontally = true;
        this.scale.pageAlignVertically = true;
        this.scale.updateLayout(true);
        this.scale.forceOrientation(false, true);
		
		this.game.add.text(0, 0, "hack", {font:"1px myfont", fill:"#FFFFFF"});
		this.game.add.text(0, 0, "jack", {font:"1px Akzidenz-Grotesk BQ", fill:"#000000"});

		//this.sound.setDecodedCallback([  ], function(){
		var param1 = sessionStorage.getItem("param2");
		console.log(param1);
        
        document.getElementById("first").style.display = "none";
        
		
		if(param1 == 1)
		{
			console.log(param1);
			this.state.start('preloader_oe_1a');
		}
		else if(param1 == 2)
		{
			console.log(param1);
			this.state.start('preloader_fm_1');
		}
		else if(param1 == 3)
		{
			console.log(param1);
			this.state.start('preloader_hcf_1');
		}
		else if(param1 == 4)
		{
			console.log(param1);
			this.state.start('preloader_prm_1');
		}
		else if(param1 == 5)
		{
			console.log(param1);
			this.state.start('preloader_fm_3');
		}
		else if(param1 == 6)
		{
			console.log(param1);
			this.state.start('preloader_fm_4a');
		}
		else if(param1 == 7)
		{
			console.log(param1);
			this.state.start('preloader_lcm_1');
		}
		else if(param1 == 8)
		{
			console.log(param1);
			this.state.start('preloader_int_1');
		}
		else if(param1 == 9)
		{
			console.log(param1);
			this.state.start('preloader_int_3');
		}
		else if(param1 == 10)
		{
			console.log(param1);
			this.state.start('preloader_int_5');
		}
		else if(param1 == 11)
		{
			console.log(param1);
			this.state.start('preloader_int_6');
		}
		else if(param1 == 12)   //hornbill game1
		{
			console.log(param1);
			this.state.start('preloader_int_5h');
		}
		else if(param1 == 13)  //hornbill game2
		{
			console.log(param1);
			this.state.start('preloader_int_6h');
		}
		else if(param1 == 14)  //hornbill game3
		{
			console.log(param1);
			this.state.start('preloader_GMPYTH_G7');
		}

	}

}

