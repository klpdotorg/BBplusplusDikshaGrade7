Game.preloader_GMLA_03_G7 = function (game) {
        this.preloadBar = null;
};

var chime, clockTick;
Game.preloader_GMLA_03_G7.prototype = {
        preload: function () {
                // this.load.video('nsrp02_1', 'demoVideos/GMLA-03-G7.mp4');   //* include demo video of game.
                this.load.image('skipArrow', 'assets/commonAssets/skipArrow.png');

                this.load.atlas('bulb', 'assets/commonAssets/bulb.png', null, GMLA_03_G7_JSON.bulbBtnJson);
                this.load.image('close', 'assets/commonAssets/close.png');
                this.load.atlas('backbtn', 'assets/commonAssets/backbtn.png', null, GMLA_03_G7_JSON.backbtnJson);
                this.load.atlas('CommonSpeakerBtn', 'assets/commonAssets/speaker.png', null, GMLA_03_G7_JSON.speakerJson);
                this.load.atlas('starAnim', 'assets/commonAssets/starAnim.png', null, GMLA_03_G7_JSON.starAnimJson);
                this.load.atlas('replay', 'assets/commonAssets/reply.png', null, GMLA_03_G7_JSON.replyJson);

                this.load.image('navBar', 'assets/commonAssets/navBar.png');
                this.load.image('timebg', 'assets/commonAssets/timebg.png');
                this.load.image('hand', 'assets/commonAssets/hand.png');

                this.load.atlas('CommonHomeBtn', 'assets/commonAssets/homeBtn.png', null, GMLA_03_G7_JSON.homebtnJson);
                this.load.atlas('CommonNextBtn', 'assets/commonAssets/nextBtn.png', null, GMLA_03_G7_JSON.nextbtnJson);

                //game grade assets

                //this.load.atlas('eraser', 'assets/gradeAssets/GMLA-03-G7/Btn_2.png', null, GMLA_03_G7_JSON.eraserJson);

                this.load.image('BG1', 'assets/gradeAssets/GMLA-03-G7/Bg.png');

                this.load.image('Loc_1', 'assets/gradeAssets/GMLA-03-G7/Loc_1.png');
                this.load.image('Loc_1_a', 'assets/gradeAssets/GMLA-03-G7/Loc_1(a).png');
                this.load.image('Loc_1_1', 'assets/gradeAssets/GMLA-03-G7/Loc_1_1.png');
                this.load.image('Loc_2', 'assets/gradeAssets/GMLA-03-G7/Loc_2.png');
                this.load.image('Loc_3', 'assets/gradeAssets/GMLA-03-G7/Loc_3.png');
                this.load.image('Loc_4', 'assets/gradeAssets/GMLA-03-G7/Loc_4.png');
                this.load.image('Loc_4_1', 'assets/gradeAssets/GMLA-03-G7/Loc_4_1.png');
                this.load.image('Loc_5', 'assets/gradeAssets/GMLA-03-G7/Loc_5.png');
                this.load.image('Loc_5_1', 'assets/gradeAssets/GMLA-03-G7/Loc_5_1.png');
                this.load.image('Loc_6', 'assets/gradeAssets/GMLA-03-G7/Loc_6.png');
                this.load.image('Loc_7', 'assets/gradeAssets/GMLA-03-G7/Loc_7.png');
                this.load.image('Loc_8', 'assets/gradeAssets/GMLA-03-G7/Loc_8.png');
                this.load.image('Loc_8_1', 'assets/gradeAssets/GMLA-03-G7/Loc_8_1.png');
                this.load.image('Loc_9', 'assets/gradeAssets/GMLA-03-G7/Loc_9.png');
                this.load.image('Loc_9_1', 'assets/gradeAssets/GMLA-03-G7/Loc_9_1.png');
                this.load.image('Loc_10', 'assets/gradeAssets/GMLA-03-G7/Loc_10.png');
                this.load.image('Loc_11', 'assets/gradeAssets/GMLA-03-G7/Loc_11.png');
                this.load.image('Loc_12', 'assets/gradeAssets/GMLA-03-G7/Loc_12.png');
                this.load.image('Loc_13', 'assets/gradeAssets/GMLA-03-G7/Loc_13.png');
                this.load.image('Loc_14', 'assets/gradeAssets/GMLA-03-G7/Loc_14.png');
                this.load.image('Loc_15', 'assets/gradeAssets/GMLA-03-G7/Loc_15.png');
                this.load.image('Loc_16', 'assets/gradeAssets/GMLA-03-G7/Loc_16.png');
                this.load.image('Loc_17', 'assets/gradeAssets/GMLA-03-G7/Loc_17.png');

                this.load.atlas('Number', 'assets/gradeAssets/GMLA-03-G7/1 to 5.png', null, GMLA_03_G7_JSON.onetofive);
                this.load.atlas('NumberCircle', 'assets/gradeAssets/GMLA-03-G7/number cercle.png', null, GMLA_03_G7_JSON.numbercercle);

              //  this.load.image('AnswerBox', 'assets/gradeAssets/GMLA-03-G7/text box.png');
                this.load.image('AnswerBox', 'assets/gradeAssets/GMLA-03-G7/text box_1.png');
                this.load.image('Red Circle_1', 'assets/gradeAssets/GMLA-03-G7/red cercle_1.png');
                this.load.image('Red Circle_2', 'assets/gradeAssets/GMLA-03-G7/red cercle_2.png');

                this.load.atlas('TickBtn', 'assets/gradeAssets/GMLA-03-G7/TickBtn.png', null, GMLA_03_G7_JSON.tickJson);

                this.load.image('numpadbg', 'assets/gradeAssets/GMLA-03-G7/numbg.png');
                this.load.atlas('Numberpad', 'assets/gradeAssets/GMLA-03-G7/number pad.png', null, GMLA_03_G7_JSON.numberpadJson);

                //hint screen assets
                this.load.image('back_arrow', 'assets/gradeAssets/GMLA-03-G7/arrow_1.png');
                this.load.image('front_arrow', 'assets/gradeAssets/GMLA-03-G7/arrow_2.png');
                this.load.image('bgbox2', 'assets/gradeAssets/GMLA-03-G7/box2.png');

        
        }, 

        create: function () {

                this.state.start('GMLA_03_G7level1');
        },
}