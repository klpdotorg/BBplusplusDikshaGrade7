Game.preloader_GMLA_01_G7 = function (game) {
        this.preloadBar = null;
};

var chime, clockTick;
Game.preloader_GMLA_01_G7.prototype = {
        preload: function () {
 
                // this.load.video('GMLA_01_G7', 'demoVideos/GMLA_01_G7.mp4');   //* include demo video of GMLA-01-G7 game
                this.load.video('GMLA1G7', 'demoVideos/GMLA-01-G7.mp4');   //* include demo video of GMLA-01-G7 game.

                this.load.atlas('bulb', 'assets/commonAssets/bulb.png', null, GMLA_01_G7_JSON.bulbBtnJson);
                this.load.image('skipArrow', 'assets/commonAssets/skipArrow.png');


                this.load.atlas('backbtn', 'assets/commonAssets/backbtn.png', null, GMLA_01_G7_JSON.backbtnJson);
                this.load.atlas('CommonSpeakerBtn', 'assets/commonAssets/speaker.png', null, GMLA_01_G7_JSON.speakerJson);
                this.load.atlas('starAnim', 'assets/commonAssets/starAnim.png', null, GMLA_01_G7_JSON.starAnimJson);
                this.load.atlas('replay', 'assets/commonAssets/reply.png', null, GMLA_01_G7_JSON.replyJson);
                this.load.image('navBar', 'assets/commonAssets/navBar.png');
                this.load.image('timebg', 'assets/commonAssets/timebg.png');
                this.load.image('hand', 'assets/commonAssets/hand.png');
                this.load.atlas('CommonHomeBtn', 'assets/commonAssets/homeBtn.png', null, GMLA_01_G7_JSON.homebtnJson);
                this.load.atlas('CommonNextBtn', 'assets/commonAssets/nextBtn.png', null, GMLA_01_G7_JSON.nextbtnJson);
                this.load.image('numpadbg', 'assets/commonAssets/numbg.png');

                this.load.image('bg', 'assets/gradeAssets/GMLA-01-G7/bg.png');
                this.load.image('graphic', 'assets/gradeAssets/GMLA-01-G7/graphic.png');
                this.load.image('blue arr', 'assets/gradeAssets/GMLA-01-G7/blue arrow1.png');
                this.load.image('blue arrow', 'assets/gradeAssets/GMLA-01-G7/blue arrow.png');
                this.load.atlas('line', 'assets/gradeAssets/GMLA-01-G7/line.png', null, GMLA_01_G7_JSON.line_Json);
                this.load.atlas('btn1', 'assets/gradeAssets/GMLA-01-G7/btn_1.png', null, GMLA_01_G7_JSON.btn_1Json);
                this.load.atlas('btn2', 'assets/gradeAssets/GMLA-01-G7/btn_2.png', null, GMLA_01_G7_JSON.btn_2Json);
                this.load.image('inProtc', 'assets/gradeAssets/GMLA-01-G7/Protractor part_1.png');
                this.load.image('outProtc', 'assets/gradeAssets/GMLA-01-G7/Protractor part_2.png');
                this.load.image('Protc', 'assets/gradeAssets/GMLA-01-G7/protr.png');
                this.load.image('smalProtc', 'assets/gradeAssets/GMLA-01-G7/image_3.png');
                this.load.image('orange arr', 'assets/gradeAssets/GMLA-01-G7/Orenge arrow1.png');
                this.load.image('orange arrow', 'assets/gradeAssets/GMLA-01-G7/Orenge arrow.png');
                this.load.image('pink arr', 'assets/gradeAssets/GMLA-01-G7/pink aerow.png');
                this.load.image('panel1', 'assets/gradeAssets/GMLA-01-G7/panle_1.png');
                this.load.image('panel2', 'assets/gradeAssets/GMLA-01-G7/panle_2.png');
                this.load.image('Text-box', 'assets/gradeAssets/GMLA-01-G7/white text box.png');
                this.load.image('Text-box2', 'assets/gradeAssets/GMLA-01-G7/text box.png');
                this.load.image('pinkcircle', 'assets/gradeAssets/GMLA-01-G7/pink ofcircle.png');
                this.load.atlas('TickBtn', 'assets/gradeAssets/GMLA-01-G7/TickBtn.png', null, GMLA_01_G7_JSON.tickJson);
                this.load.atlas('Numberpad', 'assets/gradeAssets/GMLA-01-G7/number pad.png', null, GMLA_01_G7_JSON.numberpadJson);
                this.load.atlas('Numberpad1', 'assets/gradeAssets/GMLA-01-G7/number pad1.png', null, GMLA_01_G7_JSON.numberpadJson1);
              


        },

        create: function () {
                this.state.start('GMLA_01_G7level1');
        },
}