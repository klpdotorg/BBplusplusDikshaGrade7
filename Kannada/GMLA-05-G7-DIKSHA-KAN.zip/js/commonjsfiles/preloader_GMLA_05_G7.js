Game.preloader_GMLA_05_G7 = function (game) {
        this.preloadBar = null;
};

var chime, clockTick;
Game.preloader_GMLA_05_G7.prototype = {
        preload: function () {
                // this.load.video('nsrp02_1', 'demoVideos/GMLA-05-G7.mp4');   //* include demo video of game.
                this.load.image('skipArrow', 'assets/commonAssets/skipArrow.png');
                this.load.image('close', 'assets/commonAssets/close.png');

                this.load.atlas('bulb', 'assets/commonAssets/bulb.png', null, GMLA_05_G7_JSON.bulbBtnJson);

                this.load.atlas('backbtn', 'assets/commonAssets/backbtn.png', null, GMLA_05_G7_JSON.backbtnJson);
                this.load.atlas('CommonSpeakerBtn', 'assets/commonAssets/speaker.png', null, GMLA_05_G7_JSON.speakerJson);
                this.load.atlas('starAnim', 'assets/commonAssets/starAnim.png', null, GMLA_05_G7_JSON.starAnimJson);
                this.load.atlas('replay', 'assets/commonAssets/reply.png', null, GMLA_05_G7_JSON.replyJson);

                this.load.image('navBar', 'assets/commonAssets/navBar.png');
                this.load.image('timebg', 'assets/commonAssets/timebg.png');
                 this.load.image('hand', 'assets/commonAssets/hand.png');

                this.load.atlas('CommonHomeBtn', 'assets/commonAssets/homeBtn.png', null, GMLA_05_G7_JSON.homebtnJson);
                this.load.atlas('CommonNextBtn', 'assets/commonAssets/nextBtn.png', null, GMLA_05_G7_JSON.nextbtnJson);

                //game grade assets

                this.load.image('BG1', 'assets/gradeAssets/GMLA-05-G7/Bg.png');
                
                this.load.image('cashew', 'assets/gradeAssets/GMLA-05-G7/cashew.png');
                this.load.image('cheese', 'assets/gradeAssets/GMLA-05-G7/cheese.png');
                this.load.image('cherry', 'assets/gradeAssets/GMLA-05-G7/cherry.png');
                this.load.image('close_btn', 'assets/gradeAssets/GMLA-05-G7/close btn.png');
                this.load.image('green_apple', 'assets/gradeAssets/GMLA-05-G7/green apple.png');
                this.load.image('objct_1', 'assets/gradeAssets/GMLA-05-G7/objct_1.png');
                this.load.image('objct_2', 'assets/gradeAssets/GMLA-05-G7/objct_2.png');
                this.load.image('objct_3', 'assets/gradeAssets/GMLA-05-G7/objct_3.png');
                this.load.image('orange', 'assets/gradeAssets/GMLA-05-G7/orange.png');
                this.load.image('panle_1', 'assets/gradeAssets/GMLA-05-G7/panle_1.png');
                this.load.image('panle_2', 'assets/gradeAssets/GMLA-05-G7/panle_2.png');
                this.load.image('panle_3', 'assets/gradeAssets/GMLA-05-G7/panle_3.png');
                this.load.image('panle_4', 'assets/gradeAssets/GMLA-05-G7/panle_4.png');
                this.load.image('protractor', 'assets/gradeAssets/GMLA-05-G7/protractor.png');
                this.load.image('sandwich', 'assets/gradeAssets/GMLA-05-G7/sandwich.png');
                this.load.image('strawberry', 'assets/gradeAssets/GMLA-05-G7/strawberry.png');
                this.load.image('sweet_1', 'assets/gradeAssets/GMLA-05-G7/sweet_1.png');
                this.load.image('sweet_2', 'assets/gradeAssets/GMLA-05-G7/sweet_2.png');
                this.load.image('sweet_3', 'assets/gradeAssets/GMLA-05-G7/sweet_3.png');
                this.load.image('waffer', 'assets/gradeAssets/GMLA-05-G7/sweet_4.png');
                this.load.image('watermelon', 'assets/gradeAssets/GMLA-05-G7/watermelon.png');
                this.load.image('pinkcircle', 'assets/gradeAssets/GMLA-05-G7/pink ofcircle.png');

                this.load.atlas('Angle_1', 'assets/gradeAssets/GMLA-05-G7/angle_1.png', null, GMLA_05_G7_JSON.angle_1);
                this.load.atlas('Angle_2', 'assets/gradeAssets/GMLA-05-G7/angle_2.png', null, GMLA_05_G7_JSON.angle_2);
                this.load.atlas('image_1_1', 'assets/gradeAssets/GMLA-05-G7/image_1.1.png', null, GMLA_05_G7_JSON.image_1_1);
                this.load.atlas('image_1_2', 'assets/gradeAssets/GMLA-05-G7/image_1.2.png', null, GMLA_05_G7_JSON.image_1_2);
                this.load.atlas('image_1', 'assets/gradeAssets/GMLA-05-G7/image_1.png', null, GMLA_05_G7_JSON.image_1);
                this.load.atlas('image_2', 'assets/gradeAssets/GMLA-05-G7/image_2.png', null, GMLA_05_G7_JSON.image_2);
                this.load.atlas('image_3', 'assets/gradeAssets/GMLA-05-G7/image_3.png', null, GMLA_05_G7_JSON.image_3);
                this.load.atlas('box', 'assets/gradeAssets/GMLA-05-G7/box.png', null, GMLA_05_G7_JSON.box);
                this.load.atlas('Y_and_Z', 'assets/gradeAssets/GMLA-05-G7/Y and Z.png', null, GMLA_05_G7_JSON.Y_and_Z);

                this.load.atlas('TickBtn', 'assets/gradeAssets/GMLA-05-G7/TickBtn.png', null, GMLA_05_G7_JSON.tickJson);

                //hint screen assets
                this.load.image('back_arrow', 'assets/gradeAssets/GMLA-05-G7/arrow_1.png');
                this.load.image('front_arrow', 'assets/gradeAssets/GMLA-05-G7/arrow_2.png');
                // this.load.image('close', 'assets/gradeAssets/GMLA-05-G7/close_btn.png');

                this.load.image('bgbox2', 'assets/gradeAssets/GMLA-05-G7/box2.png');
        },

        create: function () {

                this.state.start('GMLA_05_G7level1');
        },
}